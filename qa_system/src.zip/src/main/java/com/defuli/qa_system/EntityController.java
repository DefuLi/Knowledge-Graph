package com.defuli.qa_system;

import com.google.gson.Gson;
import org.neo4j.driver.v1.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Controller
@RequestMapping(value = "/entity")
public class EntityController {

    @ResponseBody
    @RequestMapping(value = "queryEntity",method = RequestMethod.POST)
    public String queryEntity(String queryContent){
        queryContent=queryContent.replace("\"","");
        //判断是否为“”
        queryContent=queryContent.replaceAll(" ","");
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        String cqlStr=String.format("match(n) where n.型号=~'(?i).*%s.*' return n",queryContent);
        StatementResult result=session.run(cqlStr);
        ArrayList<Map<String,String>> arrayList=new ArrayList<>();
        while (result.hasNext()) {
            Record record = result.next();
            Map map = new HashMap();
            String entityName = record.get(0).asNode().get("型号").toString();
            final String[] entityKeyAndValue = {""};
            Iterable<String> iterableEntityKey=record.get(0).asNode().keys();
            iterableEntityKey.forEach(entityKey->{
                //根据实体型号，找到该实体，根据实体key，找到实体value，进行字符串拼接。
                String entityValue=record.get(0).asNode().get(entityKey).toString();
                entityKeyAndValue[0] =entityKeyAndValue[0]+entityKey+"："+entityValue+"。";
            });

            map.put("实体型号", entityName);
            map.put("实体内容",entityKeyAndValue);
          //  map.put("实体内容", entityContent);
            arrayList.add(map);
        }
        Gson gson=new Gson();
        String resultJson=gson.toJson(arrayList);
        return resultJson;  //返回json数据，前端处理后，分条显示在html中。
    }
}
