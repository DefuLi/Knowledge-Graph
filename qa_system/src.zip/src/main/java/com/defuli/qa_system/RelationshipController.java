package com.defuli.qa_system;

import com.google.gson.Gson;
import org.neo4j.driver.v1.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

@Controller
@RequestMapping(value = "/relationship")
public class RelationshipController {
    public static String[] forensicProductsName=Tool.extractForensicProductsName();
    public static String[] hardwareTypeName=Tool.extractHardwareTypeName();
    public static String[] softwareTypeName=Tool.extractSoftwareTypeName();

    @ResponseBody
    @RequestMapping(value = "queryRelationship",method = RequestMethod.POST)
    public String queryRelationship(String queryContent){
        String[] relationAndEntityNameGen=extractRelationshipFromQueryContent(queryContent);
        ArrayList<String> entityName=new ArrayList<String>();
        if (relationAndEntityNameGen[0].equals("取证")){
            entityName=extractEntityFromForensicsRelation(relationAndEntityNameGen[1]);  //该list存储关系为取证的实体型号
            //接下来写的时候，一定要注意，“取证产品”不进行match查询，认为给出“硬件类型”“软件类型”
                String returnResult=processProensicFromQueryRelationship(entityName);
                return returnResult;

        }
        else if(relationAndEntityNameGen[0].equals("拥有")){
            entityName=extractEnttityFromIncludeRelation(relationAndEntityNameGen[1]);
            String returnResult=processIncludeFromQueryRelationship(entityName);
            return returnResult;
        }
        else if(relationAndEntityNameGen[0].equals("无")){
            return "无";
        }
        return "无";
    }

    //提取出关系
    public String[] extractRelationshipFromQueryContent(String queryContent){
        String[] returnResult=new String[2];
        //先提取关系 分别为“取证”、“拥有”
        int cutIndex=6;  //一般情况下倒数六个字符中会出现关系
        String lastChar=queryContent.substring(queryContent.length()-cutIndex);
        String entityNameGen="";
        String forensicsRelation="取证";
        String includeRelation="拥有";
        String temp1="包括";
        String temp2="包含";
        int indexTemp1=lastChar.indexOf(temp1);
        int indexTemp2=lastChar.indexOf(temp2);

        int indexForensicsRelation=lastChar.indexOf(forensicsRelation);
        int indexIncludeRelation=lastChar.indexOf(includeRelation);
        if (indexForensicsRelation!=-1){
            //有“取证”关系
            entityNameGen=queryContent.substring(0,queryContent.length()-cutIndex+indexForensicsRelation);
            returnResult[0]=forensicsRelation;
            returnResult[1]=entityNameGen;
            return returnResult;
        }
        else if((indexIncludeRelation!=-1)||(indexTemp1!=-1)||(indexTemp2!=-1)){
            //有“拥有”关系
            if (indexIncludeRelation!=-1){
                indexIncludeRelation=indexIncludeRelation;
            }
            if (indexTemp1!=-1){
                indexIncludeRelation=indexTemp1;
            }
            if (indexTemp2!=-1){
                indexIncludeRelation=indexTemp2;
            }
            entityNameGen=queryContent.substring(0,queryContent.length()-cutIndex+indexIncludeRelation);
            returnResult[0]=includeRelation;
            returnResult[1]=entityNameGen;
            return returnResult;
        }

        returnResult[0]="无";
        returnResult[1]="无";
        return returnResult;
    }

    //提取出“取证”关系后，接着提取实体
    public ArrayList<String> extractEntityFromForensicsRelation(String entityNameGen){
        ArrayList<String> arrayList=new ArrayList<String>();
        //“取证”关系中，相关的实体有“取证产品”以及forensicProductsName
        if (entityNameGen.indexOf("取证产品")!=-1){
            //该提问中出现了“取证产品”
            arrayList.add("取证产品");
            return arrayList;
        }

        //该提问中完全包括某一取证产品型号
        for (int i = 0; i <forensicProductsName.length ; i++) {
            if (entityNameGen.indexOf(forensicProductsName[i])!=-1){
                arrayList.add(forensicProductsName[i]);
                return arrayList;
            }
        }

        //以上两种都不符合，进行编辑距离排序
        int[][] forensicProductsNameDis=new int[forensicProductsName.length][2];  //forensicProductsNameDis第一列存储型号索引，第二列存储该型号的编辑距离
        for (int i = 0; i <forensicProductsName.length ; i++) {
            forensicProductsNameDis[i][0]=i;
            forensicProductsNameDis[i][1]=Tool.getDistance(forensicProductsName[i],entityNameGen);
        }
        //对该二维数组的距离列进行排序
        forensicProductsNameDis=Tool.sortInt(forensicProductsNameDis);
        for (int i = 0; i <5 ; i++) {  //取最相似的前五个
            arrayList.add(forensicProductsName[forensicProductsNameDis[i][0]]);
        }
        return arrayList;

    }

    //提取出“拥有”关系后，接着提取实体
    public ArrayList<String> extractEnttityFromIncludeRelation(String entityNameGen){
        ArrayList<String> arrayList=new ArrayList<String>();
        if (entityNameGen.indexOf("取证产品")!=-1){
            arrayList.add("取证产品");
            return arrayList;
        }
        if ((entityNameGen.indexOf("硬件类型")!=-1)||(entityNameGen.indexOf("硬件")!=-1)){
            arrayList.add("硬件类型");
            return arrayList;
        }
        if ((entityNameGen.indexOf("软件类型")!=-1)||(entityNameGen.indexOf("软件")!=-1)){
            arrayList.add("软件类型");
            return arrayList;
        }
        for (int i = 0; i <hardwareTypeName.length ; i++) {
            if(entityNameGen.indexOf(hardwareTypeName[i])!=-1){
                arrayList.add(hardwareTypeName[i]);
                return arrayList;
            }
        }
        for (int i = 0; i <softwareTypeName.length ; i++) {
            if(entityNameGen.indexOf(softwareTypeName[i])!=-1){
                arrayList.add(softwareTypeName[i]);
                return arrayList;
            }
        }

        return arrayList;
    }

    //对“取证”进行处理，提取出三元组
    public String processProensicFromQueryRelationship(ArrayList<String> entityNameLib){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        ArrayList<Map<String,String>> arrayList=new ArrayList<>();
        if (entityNameLib.indexOf("取证产品")!=-1){
            Map map1 = new HashMap();
            map1.put("relationStar","取证产品");
            map1.put("relationship","取证");
            map1.put("relationEnd","硬件类型");
            arrayList.add(map1);

            Map map2=new HashMap();
            map2.put("relationStar","取证产品");
            map2.put("relationship","取证");
            map2.put("relationEnd","软件类型");
            arrayList.add(map2);
            Gson gson=new Gson();
            String returnResult=gson.toJson(arrayList);
            return returnResult;
        }
        else {
            for (int i = 0; i <entityNameLib.size() ; i++) {
                String entityName=entityNameLib.get(i);
                String cqlStr=String.format("match(n)-[r:取证]->(m) where n.型号='%s' return m",entityName);
                StatementResult result=session.run(cqlStr);

                while (result.hasNext()){
                    Record record=result.next();
                    Map map = new HashMap();
                    String relationStar=entityName;
                    String relationship="取证";
                    String relationEnd=record.get(0).asNode().get("型号").toString();
                    map.put("relationStar",relationStar);
                    map.put("relationship",relationship);
                    map.put("relationEnd",relationEnd);
                    arrayList.add(map);
                }
            }

            Gson gson=new Gson();
            String returnResult=gson.toJson(arrayList);
            return returnResult;
        }
    }

    //对“拥有”进行处理，提取出三元组
    public String processIncludeFromQueryRelationship(ArrayList<String> entityNameLib){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        ArrayList<Map<String,String>> arrayList=new ArrayList<>();
        if (entityNameLib.indexOf("取证产品")!=-1){
            String cqlStr="match(n:取证产品) return n";
            StatementResult result=session.run(cqlStr);
            while (result.hasNext()){
                Record record=result.next();
                Map map = new HashMap();
                map.put("relationStar",entityNameLib.get(0));
                map.put("relationship","拥有");
                map.put("relationEnd",record.get(0).asNode().get("型号").toString());
                arrayList.add(map);
            }
            Gson gson=new Gson();
            String returnResult=gson.toJson(arrayList);
            return returnResult;
        }
        else if(entityNameLib.indexOf("硬件类型")!=-1){
            String cqlStr="match(n:硬件类型) return n";
            StatementResult result=session.run(cqlStr);
            while (result.hasNext()){
                Record record=result.next();
                Map map = new HashMap();
                map.put("relationStar",entityNameLib.get(0));
                map.put("relationship","拥有");
                map.put("relationEnd",record.get(0).asNode().get("型号").toString());
                arrayList.add(map);
            }
            Gson gson=new Gson();
            String returnResult=gson.toJson(arrayList);
            return returnResult;
        }
        else if(entityNameLib.indexOf("软件类型")!=-1){
            String cqlStr="match(n:软件类型) return n";
            StatementResult result=session.run(cqlStr);
            while (result.hasNext()){
                Record record=result.next();
                Map map = new HashMap();
                map.put("relationStar",entityNameLib.get(0));
                map.put("relationship","拥有");
                map.put("relationEnd",record.get(0).asNode().get("型号").toString());
                arrayList.add(map);
            }
            Gson gson=new Gson();
            String returnResult=gson.toJson(arrayList);
            return returnResult;
        }
        String cqlStr=String.format("match(n)-[r:拥有]-(m) where n.型号='%s' return m",entityNameLib.get(0));
        StatementResult result=session.run(cqlStr);
        while (result.hasNext()){
            Record record=result.next();
            Map map = new HashMap();
            map.put("relationStar",entityNameLib.get(0));
            map.put("relationship","拥有");
            map.put("relationEnd",record.get(0).asNode().get("型号").toString());
            arrayList.add(map);
        }
        Gson gson=new Gson();
        String returnResult=gson.toJson(arrayList);
        return returnResult;
    }
}
