package com.defuli.qa_system;

import com.google.gson.Gson;
import org.neo4j.driver.v1.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/firstKeynote")
public class FirstKeynoteController {

    @ResponseBody
    @RequestMapping(value = "/loadData",method = RequestMethod.POST)
    public String loadData(HttpServletRequest httpServletRequest){
        String selectRelation=httpServletRequest.getParameter("selectRelation").toString();
        int selectNum=Integer.parseInt(httpServletRequest.getParameter("selectNum").toString());
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        //转成图数据可识别的查询语句格式
        String cqlStr=String.format("MATCH p=()-[r:`%s`]->() RETURN p LIMIT %d",selectRelation,selectNum);
        StatementResult result=session.run(cqlStr);
        ArrayList<Map<String,String>> arrayList=new ArrayList<>();

        while (result.hasNext()){
            Record record=result.next();
            Map m = new HashMap();
            String startName=record.get(0).asPath().start().get("型号").toString();
            String startId=String.valueOf(record.get(0).asPath().start().id());
            String endName=record.get(0).asPath().end().get("型号").toString();
            String endId=String.valueOf(record.get(0).asPath().end().id());

            m.put("source",startName+startId);
            m.put("target",endName+endId);


            arrayList.add(m);
        }
        Gson gson=new Gson();
        String json=gson.toJson(arrayList);
        return json;
    }

    @ResponseBody
    @RequestMapping(value = "/dbclickNode",method = RequestMethod.POST)
    public String dbclickNode(int fouseId){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        //转成图数据可识别的查询语句格式
        String cqlStr1=String.format("match(n)-[r:取证]->(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);
        String cqlStr2=String.format("match(n)<-[r:取证]-(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);

        //较之前的中期验收新加内容
        String cqlStr3=String.format("match(n)-[r:拥有]->(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);
        String cqlStr4=String.format("match(n)<-[r:拥有]-(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);

        //正反向各查询一次
        StatementResult result1=session.run(cqlStr1);
        StatementResult result2=session.run(cqlStr2);

        StatementResult result3=session.run(cqlStr3);
        StatementResult result4=session.run(cqlStr4);

        ArrayList<Map<String,String>> arrayList=new ArrayList<>();

        while (result1.hasNext()){
            Record record=result1.next();
            Map m=new HashMap();
            String startName=record.get(0).asNode().get("name").toString();
            String startModel=record.get(0).asNode().get("型号").toString();
            String startId=String.valueOf(record.get(0).asNode().id());

            String endName=record.get(1).asNode().get("name").toString();
            String endModel=record.get(1).asNode().get("型号").toString();
            String endId=String.valueOf(record.get(1).asNode().id());

            String selectRelation=record.get(2).toString();
            if (startName.equals("NULL")){
                //策略是name为null，采用model；model为null，采用name
                m.put("source",startModel+startId);
            }
            if (startModel.equals("NULL")){
                 m.put("source",startName+startId);
            }
            if(endName.equals("NULL")){
                m.put("target",endModel+endId);
            }
            if (endModel.equals("NULL")){
                m.put("target",endName+endId);
            }

            m.put("selectRelation",selectRelation);
            arrayList.add(m);

        }
        while (result2.hasNext()){
            Record record=result2.next();
            Map m=new HashMap();
            String startName=record.get(1).asNode().get("name").toString();
            String startModel=record.get(1).asNode().get("型号").toString();
            String startId=String.valueOf(record.get(1).asNode().id());

            String endName=record.get(0).asNode().get("name").toString();
            String endModel=record.get(0).asNode().get("型号").toString();
            String endId=String.valueOf(record.get(0).asNode().id());

            String selectRelation=record.get(2).toString();
            if (startName.equals("NULL")){
                //策略是name为null，采用model；model为null，采用name
                m.put("source",startModel+startId);
            }
            if (startModel.equals("NULL")){
                m.put("source",startName+startId);
            }
            if(endName.equals("NULL")){
                m.put("target",endModel+endId);
            }
            if (endModel.equals("NULL")){
                m.put("target",endName+endId);
            }
            m.put("selectRelation",selectRelation);
            arrayList.add(m);
        }

//        while (result3.hasNext()){
//            Record record=result3.next();
//            Map m=new HashMap();
//            String startName=record.get(0).asNode().get("name").toString();
//            String startModel=record.get(0).asNode().get("型号").toString();
//            String startId=String.valueOf(record.get(0).asNode().id());
//
//            String endName=record.get(1).asNode().get("name").toString();
//            String endModel=record.get(1).asNode().get("型号").toString();
//            String endId=String.valueOf(record.get(1).asNode().id());
//
//            String selectRelation=record.get(2).toString();
//            if (startName.equals("NULL")){
//                //策略是name为null，采用model；model为null，采用name
//                m.put("source",startModel+startId);
//            }
//            if (startModel.equals("NULL")){
//                m.put("source",startName+startId);
//            }
//            if(endName.equals("NULL")){
//                m.put("target",endModel+endId);
//            }
//            if (endModel.equals("NULL")){
//                m.put("target",endName+endId);
//            }
//
//            m.put("selectRelation",selectRelation);
//            arrayList.add(m);
//
//        }
//
//        while (result4.hasNext()){
//            Record record=result4.next();
//            Map m=new HashMap();
//            String startName=record.get(0).asNode().get("name").toString();
//            String startModel=record.get(0).asNode().get("型号").toString();
//            String startId=String.valueOf(record.get(0).asNode().id());
//
//            String endName=record.get(1).asNode().get("name").toString();
//            String endModel=record.get(1).asNode().get("型号").toString();
//            String endId=String.valueOf(record.get(1).asNode().id());
//
//            String selectRelation=record.get(2).toString();
//            if (startName.equals("NULL")){
//                //策略是name为null，采用model；model为null，采用name
//                m.put("source",startModel+startId);
//            }
//            if (startModel.equals("NULL")){
//                m.put("source",startName+startId);
//            }
//            if(endName.equals("NULL")){
//                m.put("target",endModel+endId);
//            }
//            if (endModel.equals("NULL")){
//                m.put("target",endName+endId);
//            }
//
//            m.put("selectRelation",selectRelation);
//            arrayList.add(m);
//
//        }

        Gson gson=new Gson();
        String json=gson.toJson(arrayList);
        return json;
    }

    @ResponseBody
    @RequestMapping(value = "/queryDeviceName",method = RequestMethod.POST)
    public String queryDeviceName(String deviceName){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        //转成图数据可识别的查询语句格式
        String cqlStr=String.format("match(n) where n.型号 =~'.*%s.*' return n",deviceName);
        StatementResult result=session.run(cqlStr);
        ArrayList<Map<String,String>> arrayList=new ArrayList<>();

        while (result.hasNext()){
            Record record=result.next();
            Map m=new HashMap();
            String deviceNode=record.get(0).asNode().get("型号").toString();
            String deviceId=String.valueOf(record.get(0).asNode().id());
            m.put("name",deviceNode+deviceId);
            arrayList.add(m);
        }
        Gson gson=new Gson();
        String json=gson.toJson(arrayList);
        return json;
    }

    @ResponseBody
    @RequestMapping(value = "/isBelongOrInclude",method = RequestMethod.POST)
    public String isBelongOrInclude(int fouseId){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        //转成图数据可识别的查询语句格式
        String cqlStr1=String.format("match(n)-[r:取证]->(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);
        String cqlStr2=String.format("match(n)<-[r:取证]-(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);
        String cqlStr3=String.format("match(n)-[r:拥有]->(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);
        String cqlStr4=String.format("match(n)<-[r:拥有]-(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);

        //包括和属于正方向各查一次
        StatementResult result1=session.run(cqlStr1);
        StatementResult result2=session.run(cqlStr2);
        StatementResult result3=session.run(cqlStr3);
        StatementResult result4=session.run(cqlStr4);

        boolean existData1=result1.hasNext();
        boolean existData2=result2.hasNext();
        boolean existData3=result3.hasNext();
        boolean existData4=result4.hasNext();
        //返回1，该节点的关系有包括和属于
        if((existData1||existData2)&&(existData3||existData4)){
            return "1";
        }
        //返回2，该节点关系只有属于
        else if ((existData3||existData4)&&!(existData1||existData2)){
            return "2";
        }
        //返回3，其他所有情况
        else{
            return "3";
        }
    }

    @ResponseBody
    @RequestMapping(value = "/clickBelong",method = RequestMethod.POST)
    public String belong(int fouseId){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        String cqlStr1=String.format("match(n)-[r:拥有]->(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);
        String cqlStr2=String.format("match(n)<-[r:拥有]-(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);
        //正反向各查询一次
        StatementResult result1=session.run(cqlStr1);
        StatementResult result2=session.run(cqlStr2);
        ArrayList<Map<String,String>> arrayList=new ArrayList<>();

        while (result1.hasNext()){
            Record record=result1.next();
            Map m = new HashMap();

            String startName=record.get(0).asNode().get("型号").toString();
            String startId=String.valueOf(record.get(0).asNode().id());
            String endName=record.get(1).asNode().get("型号").toString();
            String endId=String.valueOf(record.get(1).asNode().id());
            String selectRelation=record.get(2).toString();
            m.put("source",startName+startId);
            m.put("target",endName+endId);
            m.put("selectRelation",selectRelation);
            arrayList.add(m);
        }

        while (result2.hasNext()){
            Record record=result2.next();
            Map m = new HashMap();

            String startName=record.get(0).asNode().get("型号").toString();
            String startId=String.valueOf(record.get(0).asNode().id());
            String endName=record.get(1).asNode().get("型号").toString();
            String endId=String.valueOf(record.get(1).asNode().id());
            String selectRelation=record.get(2).toString();
            m.put("source",startName+startId);
            m.put("target",endName+endId);
            m.put("selectRelation",selectRelation);
            arrayList.add(m);
        }

        Gson gson=new Gson();
        String json=gson.toJson(arrayList);
        return json;
    }

    @ResponseBody
    @RequestMapping(value = "/onlyBelong",method = RequestMethod.POST)
    public String onlyBelong(int fouseId){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        String cqlStr=String.format("match(n)<-[r:拥有]-(m) where id(n)=%d return n,m,type(r) limit 25",fouseId);
        StatementResult result=session.run(cqlStr);
        ArrayList<Map<String,String>> arrayList=new ArrayList<>();

        while (result.hasNext()){
            Record record=result.next();
            Map m = new HashMap();

            String startName=record.get(1).asNode().get("型号").toString();
            String startId=String.valueOf(record.get(1).asNode().id());

            String endName=record.get(0).asNode().get("型号").toString();
            String endId=String.valueOf(record.get(0).asNode().id());



            String selectRelation=record.get(2).toString();
            m.put("source",startName+startId);
            m.put("target",endName+endId);
            m.put("selectRelation",selectRelation);
            arrayList.add(m);
        }
        Gson gson=new Gson();
        String json=gson.toJson(arrayList);
        return json;
    }


    /**
     * 获得特定Id的文本内容，返回string
     * @param fouseId
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/focusIdContent",method = RequestMethod.POST)
    public String getContentById(int fouseId){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        String cqlStr=String.format("MATCH (n) WHERE ID(n)=%d RETURN n",fouseId);
        StatementResult result=session.run(cqlStr);

        String returnStr="";
        while (result.hasNext()){
            Record record=result.next();
            returnStr=record.get(0).asEntity().asMap().toString();
        }
        return returnStr;
    }
}
