package com.defuli.qa_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@SpringBootApplication
public class QaSystemApplication {

    public static void main(String[] args) throws IOException {
        SpringApplication.run(QaSystemApplication.class, args);
    }



}