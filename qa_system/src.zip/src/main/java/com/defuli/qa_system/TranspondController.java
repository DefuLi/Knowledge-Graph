package com.defuli.qa_system;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TranspondController {

    //-------------------------系统界面性函数---------------------
    @RequestMapping("/index")
    public String getIndexHtml(){
        return "index";
    }

    @RequestMapping("/help")
    public String getHelpHtml(){return "help";}

    @RequestMapping("/login")
    public String getLoginHtml(){
        return "login";
    }

    @RequestMapping("/kg")
    public String getKGHtml(){
        return "kg";
    }

    //--------------------------系统功能性函数---------------------
    @RequestMapping("/entity")
    public String getEntityHtml(){
        return "entity";
    }

    @RequestMapping("/relationship")
    public String getRelationshipHtml(){
        return "relationship";
    }

    @RequestMapping("/neo4jDataStructure")
    public String getNeo4jDataStructureHtml(){
        return "neo4jDataStructure";
    }

    @RequestMapping("/answerDetail")
    public String getAnswerDetailHtml(){
        return "answerDetail";
    }

    @RequestMapping("/property")
    public String getPropertyHtml(){
        return "property";
    }

    @RequestMapping("/product")
    public String getProductHtml(){
        return "product";
    }

    @RequestMapping("/communication")
    public String getCommunicationHtml(){return "communication";}


}
