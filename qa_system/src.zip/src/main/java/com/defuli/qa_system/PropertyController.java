package com.defuli.qa_system;

import com.google.gson.Gson;
import org.neo4j.driver.v1.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/property")
public class PropertyController {
//    public static ArrayList<String> allEntityProperty=Tool.extractAllEntityProperty();
//    public static int allEntityPropertySize=allEntityProperty.size();
//    public static String[] allEntityTypeName=Tool.extractAllEntityTypeName();
//    public static int allEntityTypeNameLen=allEntityTypeName.length;
//
//    @ResponseBody
//    @RequestMapping(value = "queryProperty",method = RequestMethod.POST)
//    public String queryProperty(String queryContent){
//        queryContent=queryContent.toLowerCase();
//        //对查询内容进行提取，提取出实体和属性
//        String[] propertyName=isHasProperty(queryContent);
//        //提取实体名
//        String entityTypeNameGen=queryContent.substring(0,queryContent.indexOf(propertyName[1]));
//        String[] mostSimilarEntityTypeName=mostSimilarEntityTypeName(entityTypeNameGen);  //最相似的五个实体型号
//        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
//        Session session=driver.session();
//        ArrayList<Map<String,String>> arrayList=new ArrayList<>();
//        for (int i = 0; i <mostSimilarEntityTypeName.length ; i++) {
//            Map map = new HashMap();
//            String cqlStr=String.format("match(n) where n.型号=~'(?i).*%s.*' return n.%s",mostSimilarEntityTypeName[i],propertyName[0]);
//            StatementResult result=session.run(cqlStr);
//            Record record=result.next();
//            String tempString=record.get(0).toString();
//
//            map.put("entityTypeName",mostSimilarEntityTypeName[i]);
//            map.put("propertyName",propertyName[1]);
//            map.put("answer",tempString);
//            arrayList.add(map);
//        }
//        Gson gson=new Gson();
//        String returnResult=gson.toJson(arrayList);
//
//        return returnResult;
//    }
//
//    //判断该问题中是否存在某个属性，并返回该属性
//    public String[] isHasProperty(String queryContent){
//        String queryContentHalf=queryContent.substring(queryContent.length()/2);
//        String[] returnResult=new String[2];  //1存储完整属性  2存储半完整属性
//        int[][] tempInt=new int[allEntityPropertySize][2];
//        String[] strings=new String[allEntityPropertySize];
//        for (int i = 0; i < allEntityPropertySize; i++) {
//            tempInt[i][0]=i;
//            strings[i]=maxSubseq(queryContentHalf,allEntityProperty.get(i).trim());
//            tempInt[i][1]=strings[i].length();  //如果dierlie全为0  说明无结果
//
//        }
//        tempInt=Tool.sortInt(tempInt);
//        returnResult[0]=allEntityProperty.get(tempInt[allEntityPropertySize-1][0]);
//
//        returnResult[1]=strings[tempInt[allEntityPropertySize-1][0]];
//
//        return returnResult;
//    }
//
//    //找出和提问中的实体最相似的5个实体
//    public String[] mostSimilarEntityTypeName(String entityTypeNameGen){
//        //先将entityTypeNameGen变为小写
//        int[][] entityTypeNameDis=new int[allEntityTypeNameLen][2];
//        for (int i = 0; i <allEntityTypeNameLen ; i++) {
//            entityTypeNameDis[i][0]=i;
//
//            entityTypeNameDis[i][1]=maxSubseq(entityTypeNameGen,allEntityTypeName[i]).length();
//
//         //   System.out.println(maxSubseq(entityTypeNameGen,allEntityTypeName[i]));
//         //   System.out.println(maxSubseq(entityTypeNameGen,allEntityTypeName[i]).length());
//         //   entityTypeNameDis[i][1]=Tool.getDistance(entityTypeNameGen,allEntityTypeName[i]);
//        }
//        entityTypeNameDis=Tool.sortInt(entityTypeNameDis);
//
//        String[] returnResult=new String[10];
//        for (int i = 0; i < 10; i++) {
//            returnResult[i]=allEntityTypeName[entityTypeNameDis[allEntityTypeNameLen-1-i][0]];
//        //    System.out.println(allEntityTypeName[entityTypeNameDis[i][0]]);
//        }
//        return returnResult;
//    }
//
//    // 求解两个字符号的最长公共子串
//    public String maxSubseq(String strOne, String strTwo){
//        // 参数检查
//        if(strOne==null || strTwo == null){
//            return null;
//        }
//        if(strOne.equals("") || strTwo.equals("")){
//            return null;
//        }
//        // 矩阵的横向长度
//        int len1 = strOne.length();
//        // 矩阵的纵向长度
//        int len2 = strTwo.length();
//        // 二维数组用来保存中间结果
//        int[][] datas = new int[len1+1][len2+1];
//        // 使用另外一个二维数组作为标记数组，用来保存从前一步到这一步的路径
//        String[][] index = new String[len1+1][len2+1];
//        // 填充二维数组
//        for(int i=1; i<=len1; i++){
//            for(int j=1; j<=len2; j++){
//                int leftTop = datas[i-1][j-1];
//                int top = datas[i-1][j];
//                int left = datas[i][j-1];
//                if(strOne.charAt(i-1) == strTwo.charAt(j-1)){
//                    leftTop ++;
//                }
//                int maxTemp = Math.max(leftTop, top);
//                datas[i][j] = Math.max(maxTemp, left);
//                // 填写标记数组
//                if(datas[i][j] == leftTop){
//                    index[i][j] = "leftTop";
//                } else if(datas[i][j]==left){
//                    index[i][j] = "left";
//                } else{
//                    index[i][j] = "top";
//                }
//            }
//        }
//        StringBuilder sBuilder = new StringBuilder();
//        // 从二维矩阵的最后一个元素向前查找结果，当（左上， 左， 上）数字相同时，查找顺序：左上-> 左 -> 上
//        int i= len1;
//        int j = len2;
//        String indexStr = "";
//        char currentCh = ' ';
//        int currentLen = 0;
//        while(i>0 && j>0){
//            currentLen = datas[i][j];
//            currentCh = strOne.charAt(i-1);
//            indexStr = index[i][j];
//            if(indexStr.equals("leftTop")){
//                i--;
//                j--;
//            } else if(indexStr.equals("left")){
//                j--;
//            } else{
//                i--;
//            }
//            if(currentLen > datas[i][j]){
//                sBuilder.insert(0, currentCh);
//            }
//        }
//        return sBuilder.toString();
//    }


}
