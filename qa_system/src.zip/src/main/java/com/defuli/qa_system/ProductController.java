package com.defuli.qa_system;

import com.defuli.el.ElasticSearchUtil;
import com.google.gson.Gson;
import org.omg.CORBA.OBJ_ADAPTER;
import org.python.antlr.ast.Str;
import org.python.core.*;
import org.python.util.PythonInterpreter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(value = "/product")
public class ProductController {
    @ResponseBody
    @RequestMapping(value = "productQA",method = RequestMethod.POST)
    public String productQA(String queryContent, HttpServletRequest request, HttpServletResponse response){
        //建立cookie 存储查询问题
        String cookieStr="";
        Cookie[] cookies=request.getCookies();
        if (cookies!=null){
            for (Cookie cookie:cookies){
                if (cookie.getName().equals("questionCookie")){
                    cookieStr=cookie.getValue();
                }
            }
        }
        cookieStr=cookieStr+"+"+queryContent;
        System.out.println(cookieStr);
        Cookie questionCookie=new Cookie("questionCookie",cookieStr);
        questionCookie.setMaxAge(30*24*60*60);
        response.addCookie(questionCookie);

        //首先调用python分类模型 IntentClassification_fasttext predict.py
        String[] cmd=new String[]{"python","G:\\python_project\\IntentClassification_fasttext\\predict.py",queryContent};
        Process pcs= null;
        try {
            pcs = Runtime.getRuntime().exec(cmd);
            pcs.waitFor();
            String classResult=null;
            BufferedInputStream in=new BufferedInputStream(pcs.getInputStream());
            BufferedReader br=new BufferedReader(new InputStreamReader(in));
            String lineStr=null;
            while ((lineStr=br.readLine())!=null){
                classResult=lineStr;
            }
            br.close();
            in.close();

            //返回product则调用刘文杰师兄专业问答程序  返回communication则调用沈毅师兄闲聊程序
            if (classResult.equals("product")){
                //专业问题
                List<Map<String, Object>> list = new ArrayList<>();
                //先调用answer函数 刘师兄写精准匹配
                String tempResult=ElasticSearchUtil.answer("testqa",queryContent);
                if (tempResult.equals("0")){
                    //没有精准答案
                    Map<String,Object> map1=new HashMap<>();
                    map1.put("question",queryContent);
                    map1.put("answer","对不起，没有匹配到精准答案");
                    list.add(map1);
                    List<Map<String, Object>> listTemp = new ArrayList<>();
                    listTemp=productFun(queryContent);
                    list.addAll(listTemp);
                    Gson gson=new Gson();
                    String returnResult=gson.toJson(list);
                    return returnResult;

                }else { //有精准答案，进行模糊匹配
                    Map<String,Object> map1=new HashMap<>();
                    map1.put("question",queryContent);
                    map1.put("answer",tempResult);
                    list.add(map1);
                    Gson gson=new Gson();
                    String returnResult=gson.toJson(list);
                    return returnResult;
                }

            }
            else if(classResult.equals("communication")){
                //闲聊问题
               // String temp=communicationFun(queryContent);
                String tempResult1=ElasticSearchUtil.answer("testqa",queryContent);
                if (tempResult1.equals("0")){
                    String temp="小Q觉得你是在闲聊，如果耐不住寂寞，请移步<a href=\"http://202.117.15.147:8004/communication\" target=\"_blank\">闲聊模块</a>";
                    return temp;
                }else {
                    //匹配到精准答案
                    List<Map<String, Object>> list = new ArrayList<>();
                    Map<String,Object> map1=new HashMap<>();
                    map1.put("question",queryContent);
                    map1.put("answer",tempResult1);
                    list.add(map1);
                    Gson gson=new Gson();
                    String returnResult=gson.toJson(list);
                    return returnResult;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        return "0";
    }



    public List<Map<String, Object>> productFun(String queryContent){
        List<Map<String, Object>> result = new ArrayList<>();
        result= ElasticSearchUtil.searchbyMultiMatch("testqa",queryContent);
        return result;
    }

    public String communicationFun(String queryContent){
        System.out.println(queryContent);
        String[] cmd=new String[]{"python","G:\\python_project\\seq2seq-chatbot\\connection.py",queryContent};
        Process pcs= null;
        String communicationResult=null;
        try {
            pcs = Runtime.getRuntime().exec(cmd);
            pcs.waitFor();
            BufferedInputStream in=new BufferedInputStream(pcs.getInputStream());
            BufferedReader br=new BufferedReader(new InputStreamReader(in,"GBK"));
            String lineStr=null;
            while ((lineStr=br.readLine())!=null){
                communicationResult=lineStr;
            }
            br.close();
            in.close();


            System.out.println(communicationResult);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return communicationResult;
    }

    @ResponseBody
    @RequestMapping(value = "recommendQuestion",method = RequestMethod.POST)
    public String recommendQuestion(String queryContent){
     //   System.out.println(queryContent);
        List<Map<String,Object>> list=ElasticSearchUtil.searchbyPhrasePrefix("testqa",queryContent);
        List<Map<String, Object>> temp=new ArrayList<>();
     //   System.out.println(list.size());
        if (list.size()>5){
            for (int i = 0; i < 5; i++) {
                temp.add(list.get(i));
            }
            list=temp;
        }
        Gson gson=new Gson();
        String returnResult=gson.toJson(list);
       // System.out.println(returnResult);
        return returnResult;
    }

    @ResponseBody
    @RequestMapping(value = "hisRecord",method = RequestMethod.POST)
    public String hisRecord(HttpServletRequest request,HttpServletResponse response){
        String cookieStr="";
        Cookie[] cookies=request.getCookies();
        if (cookies!=null){
            for (Cookie cookie:cookies){
                if (cookie.getName().equals("questionCookie")){
                    cookieStr=cookie.getValue();
                }
            }
        }
      //  String[] arr=cookieStr.split("\\+");
        return cookieStr;
    }
}
