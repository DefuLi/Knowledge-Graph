package com.defuli.qa_system;

import org.neo4j.driver.v1.*;

import javax.servlet.http.Cookie;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Tool {
//    public static void main(String[] args){
//        String[] forensicProductsName=extractForensicProductsName();
//        String[] hardwareTypeName=extractHardwareTypeName();
//        String[] softwareTypeName=extractSoftwareTypeName();
//        for (int i = 0; i <forensicProductsName.length ; i++) {
//            System.out.println(forensicProductsName[i]);
//        }
//    }

    //提取出取证产品的型号
    public static String[] extractForensicProductsName(){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        String cqlStr1="match(n:取证产品) return count(*)";
        StatementResult result1=session.run(cqlStr1);
        Record record1=result1.next();
        int forensicProductsLen=record1.get(0).asInt();

        String[] forensicProductsName=new String[forensicProductsLen];
        int flag=0;
        String cqlStr2="match(n:取证产品) return n.型号";
        StatementResult result2=session.run(cqlStr2);
        while (result2.hasNext()){
            Record record2=result2.next();
            forensicProductsName[flag]=record2.get(0).toString();
            flag++;
        }
        //去掉双引号
        for (int i = 0; i <forensicProductsName.length ; i++) {
            forensicProductsName[i]=forensicProductsName[i].replace("\"","");
        }
        return forensicProductsName;
    }

    //提取出硬件类型的型号
    public static String[] extractHardwareTypeName(){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        String cqlStr1="match(n:硬件类型) return count(*)";
        StatementResult result1=session.run(cqlStr1);
        Record record1=result1.next();
        int hardwareTypeLen=record1.get(0).asInt();

        String[] hardwareTypeName=new String[hardwareTypeLen];
        int flag=0;
        String cqlStr2="match(n:硬件类型) return n.型号";
        StatementResult result2=session.run(cqlStr2);
        while (result2.hasNext()){
            Record record2=result2.next();
            hardwareTypeName[flag]=record2.get(0).toString();
            flag++;
        }
        //去掉双引号
        for (int i = 0; i <hardwareTypeName.length ; i++) {
            hardwareTypeName[i]=hardwareTypeName[i].replace("\"","");
        }
        return hardwareTypeName;
    }

    //提取出软件类型的型号
    public static String[] extractSoftwareTypeName(){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        String cqlStr1="match(n:软件类型) return count(*)";
        StatementResult result1=session.run(cqlStr1);
        Record record1=result1.next();
        int softwareTypeLen=record1.get(0).asInt();

        String[] softwareTypeName=new String[softwareTypeLen];
        int flag=0;
        String cqlStr2="match(n:软件类型) return n.型号";
        StatementResult result2=session.run(cqlStr2);
        while (result2.hasNext()){
            Record record2=result2.next();
            softwareTypeName[flag]=record2.get(0).toString();
            flag++;
        }
        //去掉双引号
        for (int i = 0; i <softwareTypeName.length ; i++) {
            softwareTypeName[i]=softwareTypeName[i].replace("\"","");
        }
        return softwareTypeName;
    }

    //输入两个字符串，返回这两个字符串的编辑距离
    public static int getDistance(String strA, String strB) {
        int distance = -1;
        //输入参数合法性检查

        if (null == strA || null == strB || strA.isEmpty() || strB.isEmpty()) {
            return distance;
        }
        //两个字符串相等，编辑距离为0

        if (strA.equals(strB)) {
            return 0;
        }
//        System.out.println("第一个字符串：" + strA);
//        System.out.println("第二个字符串：" + strB);
        int lengthA = strA.length();
        int lengthB = strB.length();
        int length = Math.max(lengthA, lengthB);
        //申请一个二维数组，存储转移矩阵

        int array[][] = new int[length + 1][length + 1];
        //边界条件初始化

        for (int i = 0; i <= length; i++) {
            array[i][0] = i;

        }
        //边界条件初始化

        for (int j = 0; j <= length; j++) {
            array[0][j] = j;
        }
        //状态转移方程

        for (int i = 1; i <= lengthA; i++) {
            for (int j = 1; j <= lengthB; j++) {
                array[i][j] = min(array[i - 1][j] + 1,
                        array[i][j - 1] + 1,
                        array[i - 1][j - 1] + (strA.charAt(i - 1) == strB.charAt(j - 1) ? 0 : 1));
            }
        }
        //打印转移表格

//        System.out.println("状态转移表格：");
//        for (int i = 0; i <= lengthA; i++) {
//            for (int j = 0; j <= lengthB; j++) {
//                System.out.print(array[i][j] + "    ");
//            }
//            System.out.println();
//        }
        return array[lengthA][lengthB];
    }

    //取三个数中的最小值
    public static int  min(int a,int b, int c) {
        return Math.min(Math.min(a, b), c);
    }

    //对二维数组按某列进行重新排序
    public static int[][] sortInt(int[][] a){
        java.util.Arrays.sort(a,new java.util.Comparator<int[]>(){
            public int compare(int[]a,int[]b){
                return a[1]-b[1];
            }
        });
        return a;
    }

    //提取出所有实体的属性
    public static ArrayList<String> extractAllEntityProperty(){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();

        String cqlStr1="match(n) return keys(n)";
        StatementResult result1=session.run(cqlStr1);
        String stringTemp="";
        while (result1.hasNext()){
            Record record2=result1.next();
            String entityProperty=record2.get(0).toString();
         //   System.out.println(entityProperty);
            stringTemp=stringTemp+entityProperty;
        }
        ArrayList<String> arrayList=extractDouQuoMarksSubStr(stringTemp);
        return arrayList;
    }

    //提取出所有实体的型号
    public static String[] extractAllEntityTypeName(){
        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
        Session session=driver.session();
        String cqlStr1="match(n) return count(n)";
        StatementResult result1=session.run(cqlStr1);
        Record record1=result1.next();
        int allEntityTypeNameLen=record1.get(0).asInt();
        String[] allEntityTypeName=new String[allEntityTypeNameLen];

        String cqlStr2="match(n) return n.型号";
        StatementResult result2=session.run(cqlStr2);
        int flag=0;
        while (result2.hasNext()){
            Record record2=result2.next();
            allEntityTypeName[flag]=record2.get(0).toString();
            allEntityTypeName[flag]=allEntityTypeName[flag].replace("\"","");
            allEntityTypeName[flag]=allEntityTypeName[flag].toLowerCase();
            flag++;
        }

        return allEntityTypeName;
    }

    //提取字符串中双引号下的子字符串 已去重
    public static ArrayList<String> extractDouQuoMarksSubStr(String string){
        Pattern p1=Pattern.compile("\"(.*?)\"");
        Matcher m=p1.matcher(string);
        StringBuilder stringBuilder=new StringBuilder();
        ArrayList<String> list=new ArrayList<String>();
        while (m.find()){
            list.add(m.group().trim().replace("\"","")+" ");
        }
        list=listRemoveDuplicats(list);
        return list;

    }

    //list去重
    public static ArrayList<String> listRemoveDuplicats(ArrayList<String> list){
        Set<String> set=new LinkedHashSet<>();
        set.addAll(list);
        list.clear();
        list.addAll(set);
        return list;
    }

}

