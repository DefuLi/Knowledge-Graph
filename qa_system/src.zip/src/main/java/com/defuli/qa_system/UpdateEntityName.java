package com.defuli.qa_system;

import org.neo4j.driver.v1.*;
import org.springframework.boot.SpringApplication;

import java.io.IOException;

public class UpdateEntityName {
   // public static String[] allEntityTypeName=Tool.extractAllEntityTypeName();

    public static void main(String[] args) throws IOException {
//        Driver driver= GraphDatabase.driver("bolt://127.0.0.1:7687", AuthTokens.basic("qiuqi","123456"));
//        Session session=driver.session();
//
//        for (int i = 0; i < allEntityTypeName.length; i++) {
//            allEntityTypeName[i]=allEntityTypeName[i].replaceAll("\"","");
//            String tempStr=allEntityTypeName[i].replaceAll(" ","");
//            String cqlStr=String.format("match(n) where n.型号='%s' set n.型号='%s' return n",allEntityTypeName[i],tempStr);
//            StatementResult result=session.run(cqlStr);
//        }
//        System.out.println("完毕");

        String temp="+我想吃饭+你爱我吗+我觉得你在闲聊";
        String[] arr=temp.split("\\+");
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }
}
