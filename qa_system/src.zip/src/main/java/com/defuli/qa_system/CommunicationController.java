package com.defuli.qa_system;

import org.python.antlr.ast.Str;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

@Controller
@RequestMapping(value = "/communication")
public class CommunicationController {
    @ResponseBody
    @RequestMapping(value = "comm",method = RequestMethod.POST)
    public String commQA(String queryContent){
        System.out.println(queryContent);
        String[] cmd=new String[]{"python","G:\\python_project\\seq2seq-chatbot\\connection.py",queryContent};
        Process pcs= null;
        String communicationResult=null;
        try {
            pcs = Runtime.getRuntime().exec(cmd);
            pcs.waitFor();
            BufferedInputStream in=new BufferedInputStream(pcs.getInputStream());
            BufferedReader br=new BufferedReader(new InputStreamReader(in,"GBK"));
            String lineStr=null;
            while ((lineStr=br.readLine())!=null){
                communicationResult=lineStr;
            }
            br.close();
            in.close();


            System.out.println(communicationResult);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return communicationResult;
    }

}
