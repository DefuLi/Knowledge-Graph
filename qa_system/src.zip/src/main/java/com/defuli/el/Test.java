package com.defuli.el;

import static org.elasticsearch.common.xcontent.XContentFactory.jsonBuilder;


import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import org.apache.log4j.PropertyConfigurator;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Test {
	private static Logger logger1 = LoggerFactory.getLogger(Test.class); 
	public static void main(String[] args) throws IOException {
		
		Properties props = null;
		FileInputStream fis = null;
		try {
			// 从配置文件dbinfo.properties中读取配置信息
			props = new Properties();
			fis = new FileInputStream("src/log4j.properties");
			props.load(fis);
			PropertyConfigurator.configure(props);//装入log4j配置信息
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fis != null)
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			fis = null;
		}
		 // 记录debug级别的信息  
        //logger1.debug("This is debug message.");
        // 记录info级别的信息  
        //logger1.info("This is info message.");
        // 记录error级别的信息  
        //logger1.error("This is error message.");
        ElasticSearchUtil.getClusterInfo();
        //ElasticSearchUtil.deleteIndex("testqa");
		//createindex();
        //ElasticSearchUtil.getAllIndex();
		ElasticSearchUtil.insertDatafromExcel("F:\\EL\\data-el\\table.xlsx", "testqa","QA");
		//ElasticSearchUtil.getOneDocument("testqa", "QA", "2708");
		//ElasticSearchUtil.analyze("megacorp","中华人民共和国");
        //ElasticSearchUtil.searchbyBaseWord("test", "question", "机器");
        //ElasticSearchUtil.searchbyFuzzy("testqa", "DBR");
       // ElasticSearchUtil.searchbyMultiMatch("testqa", "取证大师可以取证什么");
        System.out.println("===============");
        //ElasticSearchUtil.searchbyBoost("testqa", "苹果不拆机复制");
        //ElasticSearchUtil.searchbyPhrasePrefix("testqa", "取证");
        
	}
	public static void createindex() throws IOException {
		//创建settings
		/*
		Settings settings = Settings.builder().loadFromSource(jsonBuilder()
				.startObject()
				.field("number_of_shards",1)
				.field("number_of_replicas",1)
				  .startObject("analysis")
				    .startObject("filter")
				      .startObject("local_synonym")
				        .field("type", "synonym")
				        .field("synonyms_path","analysis/synonym.txt")
				      .endObject()
				    .endObject()
				    .startObject("analyzer")
				      .startObject("ik-index")
				        .field("type","custom")
				        .field("tokenizer","ik_max_word")
				        .field("filter",new String[]{"local_synonym"})
				      .endObject()
				      .startObject("ik-smart")
				        .field("type","custom")
				        .field("tokenizer","ik_smart")
				        .field("filter",new String[]{"local_synonym"})
				      .endObject()
				    .endObject()
				  .endObject()
				.endObject().toString(), XContentType.JSON).build();
		*/
		Path path = Paths.get("F:\\EL\\data-el\\settings.json");
		String set = new String(Files.readAllBytes(path));
		System.out.println(set);
		Settings settings1 = Settings.builder().loadFromSource(set, XContentType.JSON).build();
		//创建mappings
		XContentBuilder content = jsonBuilder()
				.startObject()
				.startObject("properties")
				.startObject("question")
				.field("type","text")
				.field("analyzer","ik-index")
				.field("search_analyzer","ik-smart")
				.field("boost",2f)
				.endObject()
				.startObject("product_name")
				.field("type","keyword")
				.field("boost",10f)
				.endObject()
				.startObject("genre")
				.field("type","text")
				.field("index",false)
				.endObject()
				.startObject("answer")
				.field("type","text")
				.field("analyzer","ik-smart")
				.field("search_analyzer","ik-smart")
				.field("boost",0.5f)
				.endObject()
				.endObject()
				.endObject();
		ElasticSearchUtil.createIndex("testqa", settings1, "QA", content);
	}
}
