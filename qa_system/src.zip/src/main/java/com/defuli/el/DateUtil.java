package com.defuli.el;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	public static String getDays()
	{
		 DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");  
	     return sdf.format(new Date()); 
	}
	
	
	public static void main(String[] args) {
		System.out.println(getDays());
	}
}
