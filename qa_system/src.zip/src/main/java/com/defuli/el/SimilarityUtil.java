package com.defuli.el;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.lucene.util.ArrayUtil;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.dictionary.CustomDictionary;

public final class SimilarityUtil {
	  //添加自定义分词
	  static {
          //CustomDictionary.add("取证大师");
          //CustomDictionary.add("取证航母");
      }
	  private SimilarityUtil() {
		  
	  }
	  public static double getSimilarity(String sentence1, String sentence2) {
	        List<String> sent1Words = getSplitWords(sentence1);
	        List<String> sent2Words = getSplitWords(sentence2);
	        List<String> allWords = mergeList(sent1Words, sent2Words);

	        int[] statistic1 = statistic(allWords, sent1Words);
	        int[] statistic2 = statistic(allWords, sent2Words);

	        double dividend = 0;
	        double divisor1 = 0;
	        double divisor2 = 0;
	        for (int i = 0; i < statistic1.length; i++) {
	            dividend += statistic1[i] * statistic2[i];
	            divisor1 += Math.pow(statistic1[i], 2);
	            divisor2 += Math.pow(statistic2[i], 2);
	        }

	        return dividend / (Math.sqrt(divisor1) * Math.sqrt(divisor2));
	    }

	    private static int[] statistic(List<String> allWords, List<String> sentWords) {
	        int[] result = new int[allWords.size()];
	        for (int i = 0; i < allWords.size(); i++) {
	            result[i] = Collections.frequency(sentWords, allWords.get(i));
	        }
	        return result;
	    }

	    private static List<String> mergeList(List<String> list1, List<String> list2) {
	        List<String> result = new ArrayList<>();
	        result.addAll(list1);
	        result.addAll(list2);
	        return result.stream().distinct().collect(Collectors.toList());
	    }

	    private static List<String> getSplitWords(String sentence) {
	        // 标点符号会被单独分为一个Term，去除之
	        return HanLP.segment(sentence).stream().map(a -> a.word).filter(s -> !"`~!@#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？".contains(s)).collect(Collectors.toList());
	    }
	    public static void main(String[] args) {
			String string = "DBR";
			List<String> list = getSplitWords(string);
			System.out.println(Arrays.toString(list.toArray()));
		}
}
