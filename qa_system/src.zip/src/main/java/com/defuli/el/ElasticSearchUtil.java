package com.defuli.el;

import java.io.FileInputStream;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.elasticsearch.action.ActionFuture;
import org.elasticsearch.action.admin.cluster.state.ClusterStateResponse;
import org.elasticsearch.action.admin.indices.analyze.AnalyzeAction;
import org.elasticsearch.action.admin.indices.analyze.AnalyzeRequest;
import org.elasticsearch.action.admin.indices.analyze.AnalyzeRequestBuilder;
import org.elasticsearch.action.admin.indices.analyze.AnalyzeResponse;
import org.elasticsearch.action.admin.indices.analyze.AnalyzeResponse.AnalyzeToken;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequest;
import org.elasticsearch.action.admin.indices.create.CreateIndexResponse;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsRequest;
import org.elasticsearch.action.admin.indices.exists.indices.IndicesExistsResponse;
import org.elasticsearch.action.bulk.BulkRequestBuilder;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.delete.DeleteRequestBuilder;
import org.elasticsearch.action.delete.DeleteResponse;
import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.action.support.master.AcknowledgedResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.cluster.node.DiscoveryNode;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.common.xcontent.XContentBuilder;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.discovery.zen.NodeJoinController.ElectionCallback;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.FuzzyQueryBuilder;
import org.elasticsearch.index.query.MatchPhrasePrefixQueryBuilder;
import org.elasticsearch.index.query.MatchPhraseQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.MultiMatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.QueryStringQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramAggregationBuilder;
import org.elasticsearch.search.aggregations.bucket.histogram.DateHistogramInterval;
import org.elasticsearch.search.aggregations.bucket.histogram.ExtendedBounds;
import org.elasticsearch.search.aggregations.bucket.histogram.Histogram;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.bucket.terms.TermsAggregationBuilder;
import org.elasticsearch.search.aggregations.metrics.sum.Sum;
import org.elasticsearch.search.aggregations.metrics.sum.SumAggregationBuilder;
import org.elasticsearch.search.sort.SortBuilders;
import org.elasticsearch.transport.client.PreBuiltTransportClient;


import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.common.Term;



public class ElasticSearchUtil {
	private static final Logger logger = LoggerFactory.getLogger(ElasticSearchUtil.class);
	private static TransportClient client = StaticContant.ESCLIENT;
	private static List<String> JsonEleName = new ArrayList<String>();
	static{
		JsonEleName.add("question");
		JsonEleName.add("product_name");
		JsonEleName.add("type");
		JsonEleName.add("answer");
	}
	public ElasticSearchUtil (String clusterName, String ip, int port) {
		try {
			Settings settings = Settings.builder()
					.put("cluster.name", clusterName) 	//设置集群名
	                .put("client.transport.sniff", true) 		//启动嗅探功能,自动嗅探整个集群的状态，把集群中其他ES节点的ip添加到本地的客户端列表中
	                .put("client.transport.ignore_cluster_name", true)//忽略集群名字验证, 打开后集群名字不对也能连接上
	                .put("client.transport.nodes_sampler_interval", 5)//报错
	                .put("client.transport.ping_timeout", 5) 		//报错, ping等待时间
	                .build();
	        // 创建client,通过setting来创建，若不指定则默认链接的集群名为elasticsearch,链接使用tcp协议即9300
	        // addTransportAddress此步骤添加IP，至少一个，其实一个就够了，因为添加了自动嗅探配置
			this.client = new PreBuiltTransportClient(settings)
	                .addTransportAddress(new TransportAddress(InetAddress.getByName(ip), port));
		} catch (Exception e) {
			logger.error("es init failed! " + e.getMessage());
	    }
	}
	/**
     * 查看集群信息
     */
    public static void getClusterInfo() {
        List<DiscoveryNode> nodes = client.connectedNodes();
        for (DiscoveryNode node : nodes) {
        //    System.out.println("HostId:"+node.getHostAddress()+" hostName:"+node.getHostName()+" Address:"+node.getAddress());
           
        }
    }
    /**
     * 功能描述：新建索引
     * @param indexName 索引名
     */
    public static void createIndex(String indexName) {
        try {
			if (indexExist(indexName)) {
			//    System.out.println("The index " + indexName + " already exits!");
			} else {
			    CreateIndexResponse cIndexResponse = client.admin().indices()
			    		.create(new CreateIndexRequest(indexName))
			            .actionGet();
			    if (cIndexResponse.isAcknowledged()) {
			  //      System.out.println("create index successfully！");
			    } else {
			  //      System.out.println("Fail to create index!");
			    }
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
 
    /**
     * 功能描述：新建索引
     * @param index 索引名
     * @param type 类型
     */
    public static void createIndex(String index, String type) {
        try {
			client.prepareIndex(index, type).setSource().get();
		} catch (Exception e) {
		//	System.out.println("Fail to create index!");
			e.printStackTrace();
		}
    }
    /**
     * 功能描述：新建索引
     * @param index     索引名
     * @param settings  设置
     * @param type	            类型
     * @param content   映射
     */
    public static void createIndex(String index, Settings settings,String type,XContentBuilder content)
    {
    	 try {
    		 CreateIndexResponse cIndexResponse = client.admin().indices().prepareCreate(index).setSettings(settings).addMapping(type, content).get();
    		 if (cIndexResponse.isAcknowledged()) {
    		//	 System.out.println("create index successfully！");
			 } else {
			//	 System.out.println("Fail to create index!");
			 }
    	 } catch (Exception e) {
 		//	System.out.println("Fail to create index!");
 			e.printStackTrace();
 		}
    	
    }
    /**
     * 功能描述：删除索引
     * @param index 索引名
     */
    public static void deleteIndex(String index) {
        try {
			if (indexExist(index)) {
			    AcknowledgedResponse dResponse = client.admin().indices().prepareDelete(index)
			            .execute().actionGet();
			    if (!dResponse.isAcknowledged()) {
			        logger.info("failed to delete index " + index + "!");
			    }else {
			    	logger.info("delete index " + index + " successfully!");
			    }
			} else {
			    logger.error("the index " + index + " not exists!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

    /**
     * 功能描述：验证索引是否存在
     * @param index 索引名
     */
    public static boolean indexExist(String index) {
        IndicesExistsRequest inExistsRequest = new IndicesExistsRequest(index);
        IndicesExistsResponse inExistsResponse = client.admin().indices()
                .exists(inExistsRequest).actionGet();
        return inExistsResponse.isExists();
    }
    /**
     * 获得表格一行的json数据     除第一列的id
     * @param sheet
     * @param index
     * @return
     */
    public static JSONObject getJsonDatafromExcel(Sheet sheet,int index){
    	Row row = sheet.getRow(index);
    	JSONObject jsonObject = new JSONObject();
    	//获取最大列数
        int colnum = row.getPhysicalNumberOfCells();
        for (int j=0;j<colnum-1;j++){
            Object cellData =  EXCELBean.getCellFormatValue(row.getCell(j+1));
            jsonObject.put(JsonEleName.get(j), cellData);
        }
    	return jsonObject;	
    }
    /**
     * 获得id从表格第一列
     * @param sheet
     * @param index
     * @return
     */
    public static String getIdfromFirstColinExcel(Sheet sheet,int index){
    	Row row = sheet.getRow(index);
    	String cellData =  (String) EXCELBean.getCellFormatValue(row.getCell(0));
    //	System.out.println(cellData);
    	return cellData;
    }
    /**
     * 从excel中获得数据插入指定的索引中
     * @param path
     * @param index
     * @param type
     */
	public static void insertDatafromExcel(String path,String index, String type){
		FileInputStream inputStream = null;
        try{
            inputStream = new FileInputStream(path);
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            //获取第一个sheet
            Sheet sheet = workbook.getSheetAt(0);
            //获取最大行数
            int rownum = sheet.getPhysicalNumberOfRows();
         //   System.out.println(rownum);
            for(int i=0;i<rownum;i++){
            	String id = getIdfromFirstColinExcel(sheet,i);
            	if (id == ""|| id == null) {
					break;
				}
            	JSONObject jsonObject = getJsonDatafromExcel(sheet,i);
            	insertData(index, type,id, jsonObject);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if (inputStream!=null){
                try {
                    inputStream.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        }
	}

   	/**
     * 功能描述：获取所有的索引
     */
    public static void getAllIndex(){
        ClusterStateResponse response = client.admin().cluster().prepareState().execute().actionGet();
        //获取所有索引
        String[] indexs=response.getState().getMetaData().getConcreteAllIndices();
     //   System.out.println("Index总数为: " + indexs.length);
        for (String index : indexs) {
      //     System.out.println("获取的Index: " + index);
        }
    }
    /**
     * 功能描述：插入数据  
     * @param index 索引名
     * @param type 类型
     * @param id 
     * @param json 数据
     */
   	public static void insertData(String index, String type, String id, JSONObject json) {
       IndexResponse response = client.prepareIndex(index, type).setId(id)
               .setSource(json.toString(),XContentType.JSON)
               .get();
    //   System.out.println(response.getVersion());
       logger.info("数据插入ES成功！");
    }
    /**
     * 通过prepareIndex增加文档，参数为json字符串
     * @param index 索引名
     * @param type  类型
     * @param _id   数据id
     * @param json  数据
     */
	public static void insertData(String index, String type, String _id, String json) {
        IndexResponse indexResponse = client.prepareIndex(index, type).setId(_id)
                .setSource(json)
                .get();
     //   System.out.println(indexResponse.getVersion());
		logger.info("数据插入ES成功！");
    }
	/**
     * 功能描述：更新数据
     * @param index 索引名
     * @param type  类型
     * @param _id   数据id
     * @param json  数据
     */
	public static void updateData(String index, String type, String _id, String json){
        try {
            UpdateRequest updateRequest = new UpdateRequest(index, type, _id).doc(json);
//          client.prepareUpdate(index, type, _id).setDoc(json).get();
            client.update(updateRequest).get();
        } catch (Exception e) {
            logger.error("update data failed." + e.getMessage());
        }
    }
 
    /**
     * 功能描述：删除指定数据
     * @param index 索引名
     * @param type  类型
     * @param _id   数据id
     */
    public static void deleteData(String index, String type, String _id) {
        try {
			DeleteResponse response = client.prepareDelete(index, type, _id).get();
		//	System.out.println(response.isFragment());
			logger.info("删除指定数据成功！");
		} catch (Exception e) {
			logger.error("删除指定数据失败！" + e);
		}
    }
    /**
   	 * 删除索引类型表所有数据，批量删除
   	 * @param index
   	 * @param type
   	 */
   	public static void deleteIndexTypeAllData(String index, String type) {
   		SearchResponse response = client.prepareSearch(index).setTypes(type)
   				.setQuery(QueryBuilders.matchAllQuery()).setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
   					.setScroll(new TimeValue(60000)).setSize(10000).setExplain(false).execute().actionGet();
   		BulkRequestBuilder bulkRequest = client.prepareBulk();
   		while (true) {
   			SearchHit[] hitArray = response.getHits().getHits();
   			SearchHit hit = null;
   			for (int i = 0, len = hitArray.length; i < len; i++) {
   				hit = hitArray[i];
   				DeleteRequestBuilder request = client.prepareDelete(index, type, hit.getId());
   				bulkRequest.add(request);
   			}
   			BulkResponse bulkResponse = bulkRequest.execute().actionGet();
   			if (bulkResponse.hasFailures()) {
   				logger.error(bulkResponse.buildFailureMessage());
   			}
   			if (hitArray.length == 0) break;
   			response = client.prepareSearchScroll(response.getScrollId())
   							.setScroll(new TimeValue(60000)).execute().actionGet();
   		}
   	}
    
       /**
        * 功能描述：批量插入数据
        * @param index    索引名
        * @param type     类型
        * @param jsonList 批量数据
        */
      
   	 public void bulkInsertData(String index, String type, List<String> jsonList) {
		   BulkRequestBuilder bulkRequest = client.prepareBulk();
		   jsonList.forEach(item -> {
		       bulkRequest.add(client.prepareIndex(index, type).setSource(item));
		   });
		   BulkResponse bulkResponse = bulkRequest.get();
		   if(!bulkResponse.hasFailures()) {
		//   	System.out.println(bulkResponse.getItems().length + "条数据插入完成！");
		   }
     }
   	 /**
      * 通过prepareGet方法获取指定文档信息
      */
     public static void getOneDocument(String index, String type, String id) {
     	// 搜索数据  
         GetResponse response = client.prepareGet(index, type, id)
//                 .setOperationThreaded(false)    // 线程安全
                 .get();
       //  System.out.println(response.isExists());  // 查询结果是否存在
       //  System.out.println("***********"+response.getSourceAsString());//获取文档信息
//       System.out.println(response.toString());//获取详细信息
     }

     /**
      * 通过prepareSearch方法获取指定索引所有文档信息
      */
     public static List<Map<String, Object>> getDocuments(String index) {
     	List<Map<String, Object>> mapList = new ArrayList<>();
     	// 搜索数据  
     	SearchResponse response = client.prepareSearch(index)
//     			.setTypes("type1","type2"); //设置过滤type
//     			.setTypes(SearchType.DFS_QUERY_THEN_FETCH)  精确查询
//     			.setQuery(QueryBuilders.matchQuery(term, queryString));
//     			.setFrom(0) //设置查询数据的位置,分页用
//     			.setSize(60) //设置查询结果集的最大条数
//     			.setExplain(true) //设置是否按查询匹配度排序
     			.get(); //最后就是返回搜索响应信息
     //	System.out.println("共匹配到:"+response.getHits().getTotalHits()+"条记录!");
     	SearchHit[] hits = response.getHits().getHits();
     	for (SearchHit hit : hits) {
 			Map<String, Object> source = hit.getSourceAsMap();
 			mapList.add(source);
 		}
     //	System.out.println(response.getTotalShards());//总条数
     	return mapList;
     }
     /**
      * 应答
      * @param index
      * @param question
      * @return
      */
     public static String answer(String index,String question){
    	 List<Term> list = HanLP.segment(question);
    	 List<Map<String, Object>> result = null;
    	 int size = list.size();
    	 if (size == 1) {
    	//	 System.out.println("size=1");
    		 result= searchbyFuzzy(index, question);
    		 String string = isHasanswer1(result, question);
    		 return string;
		 }
    	 else if(size>=2 && size<=5 ){
    	//	 System.out.println("size<=6 size>=2");
    		 result = ElasticSearchUtil.searchbyMultiMatch(index,question);
    	 }
    	 else {
    	//	 System.out.println("size>6");
    		 result = ElasticSearchUtil.searchbyMultiMatch(index,question,true);
		 }
    	 String string = isHasanswer(result, question);
    	 return string;
     }
     /**
      * 基本词查询 基本词不会被切割
      * @param index
      * @param field
      * @param keyWord
      * @return
      */
     public static List<Map<String, Object>> searchbyBaseWord(String index,String field, String keyWord){
    	 QueryBuilder qBuilder = QueryBuilders.termQuery(field, keyWord);
    	 SearchResponse searchResponse = client.prepareSearch(index).setQuery(qBuilder).execute().actionGet();
		 SearchHits hits = searchResponse.getHits();
		 List<Map<String, Object>> result = new ArrayList<>();
		 for(SearchHit hit:hits){
			 Map<String, Object> map = hit.getSourceAsMap();
			 result.add(map);
			 for(final Entry<String, Object> entry:map.entrySet()){
			//	 System.out.println(entry.getKey()+":"+entry.getValue());
			 }
		 }
    	 return result;   	
     }
     /**
      * 不带权重的查询
      * @param index
      * @param keyword
      * @return
      */
      public static List<Map<String, Object>> searchbyMultiMatch(String index,String keyword){
    	  
    	  MultiMatchQueryBuilder qBuilder = QueryBuilders.multiMatchQuery(keyword, "question","answer","product_name");
    	  SearchResponse searchResponse = client.prepareSearch(index).setQuery(qBuilder).execute().actionGet();
    	  SearchHits hits = searchResponse.getHits();
 		  List<Map<String, Object>> result = new ArrayList<>();
 		  for(SearchHit hit:hits){
 			  Map<String, Object> map = hit.getSourceAsMap();
 			  result.add(map);
 			  for(final Entry<String, Object> entry:map.entrySet()){
 				//  System.out.println(entry.getKey()+":"+entry.getValue());
 			  }
 		  }
     	  return result;   	
      }
      /**
       * 不带权重的查询  模糊
       * @param index
       * @param keyword
       * @return
       */
       public static List<Map<String, Object>> searchbyMultiMatch(String index,String keyword,boolean isFuzzy){
     	  if (isFuzzy) {
     		  MultiMatchQueryBuilder qBuilder = QueryBuilders.multiMatchQuery(keyword, "question","answer","product_name").fuzziness("AUTO");
        	  SearchResponse searchResponse = client.prepareSearch(index).setQuery(qBuilder).execute().actionGet();
        	  SearchHits hits = searchResponse.getHits();
     		  List<Map<String, Object>> result = new ArrayList<>();
     		  for(SearchHit hit:hits){
     			  Map<String, Object> map = hit.getSourceAsMap();
     			  result.add(map);
     			  for(final Entry<String, Object> entry:map.entrySet()){
     				//  System.out.println(entry.getKey()+":"+entry.getValue());
     			  }
     		  }
         	  return result;   	
		  }
     	  else{
     		 List<Map<String, Object>> result = new ArrayList<>();
     		 result = searchbyMultiMatch(index,keyword);
     		 return result;
     	  }
     	 
       }
      /**
       * 带权重的查询 
       * @param index
       * @param keyword
       * @return
       */
      public static List<Map<String, Object>> searchbyBoost(String index,String keyword){
    	  MatchQueryBuilder q_question = QueryBuilders.matchQuery("question", keyword).boost(2f);
    	  MatchQueryBuilder q_answer = QueryBuilders.matchQuery("answer", keyword).boost(0.5F);
    	  MatchQueryBuilder q_product_name = QueryBuilders.matchQuery("product_name", keyword).boost(10f);
    	  QueryBuilder qBuilder = QueryBuilders.boolQuery().should(q_question).should(q_answer).should(q_product_name);
    	  SearchResponse searchResponse = client.prepareSearch(index).setQuery(qBuilder).execute().actionGet();
    	  SearchHits hits = searchResponse.getHits();
 		  List<Map<String, Object>> result = new ArrayList<>();
 		  for(SearchHit hit:hits){
 			  Map<String, Object> map = hit.getSourceAsMap();
 			  result.add(map);
 			  for(final Entry<String, Object> entry:map.entrySet()){
 				//  System.out.println(entry.getKey()+":"+entry.getValue());
 			  }
 		  }
     	  return result;   	
      }
      /**
       * 带权重的查询 模糊
       * @param index
       * @param keyword
       * @return
       */
      public static List<Map<String, Object>> searchbyBoost(String index,String keyword,boolean isFuzzy){
    	  MatchQueryBuilder q_question,q_answer,q_product_name;
    	  if (isFuzzy) {
    		  q_question = QueryBuilders.matchQuery("question", keyword).boost(2.5f).fuzziness("AUTO");
        	  q_answer = QueryBuilders.matchQuery("answer", keyword).boost(0.5F).fuzziness("AUTO");
        	  q_product_name = QueryBuilders.matchQuery("product_name", keyword).boost(10f).fuzziness("AUTO");
        	  QueryBuilder qBuilder = QueryBuilders.boolQuery().should(q_question).should(q_answer).should(q_product_name);
        	  SearchResponse searchResponse = client.prepareSearch(index).setQuery(qBuilder).execute().actionGet();
        	  SearchHits hits = searchResponse.getHits();
     		  List<Map<String, Object>> result = new ArrayList<>();
     		  for(SearchHit hit:hits){
     			  Map<String, Object> map = hit.getSourceAsMap();
     			  result.add(map);
     			  for(final Entry<String, Object> entry:map.entrySet()){
     				//  System.out.println(entry.getKey()+":"+entry.getValue());
     			  }
     		  }
         	  return result;   	
		  }
    	  else{
    		  List<Map<String, Object>> result = new ArrayList<>();
      		 result = searchbyMultiMatch(index,keyword);
      		 return result;
    	  }
		  
      }
      /**
       * 带有词语前缀的查询
       * @param index
       * @param keyword
       * @return
       */
      public static List<Map<String, Object>> searchbyPhrasePrefix(String index,String keyword){
    	  MatchPhrasePrefixQueryBuilder qBuilder = QueryBuilders.matchPhrasePrefixQuery("question", keyword);
    	  SearchResponse searchResponse = client.prepareSearch(index).setQuery(qBuilder).execute().actionGet();
    	  SearchHits hits = searchResponse.getHits();
 		  List<Map<String, Object>> result = new ArrayList<>();
 		  for(SearchHit hit:hits){
 			  Map<String, Object> map = hit.getSourceAsMap();
 			  result.add(map);
 			  for(final Entry<String, Object> entry:map.entrySet()){
 				//  System.out.println(entry.getKey()+":"+entry.getValue());
 			  }
 		  }
     	  return result;   	
      }
      /**
       * 模糊查询
       * @param index
       * @param keyword
       * @return
       */
      public static List<Map<String, Object>> searchbyFuzzy(String index,String keyword){
    	  MatchQueryBuilder queryBuilder = QueryBuilders.matchQuery("question", keyword).fuzziness("AUTO");
    	  //FuzzyQueryBuilder queryBuilder = QueryBuilders.fuzzyQuery("question", keyword);
    	  SearchResponse searchResponse = client.prepareSearch(index).setQuery(queryBuilder).execute().actionGet();
    	  SearchHits hits = searchResponse.getHits();
 		  List<Map<String, Object>> result = new ArrayList<>();
 		  for(SearchHit hit:hits){
 			  Map<String, Object> map = hit.getSourceAsMap();
 			  result.add(map);
 			  for(final Entry<String, Object> entry:map.entrySet()){
 				//  System.out.println(entry.getKey()+":"+entry.getValue());
 			  }
 		  }
     	  return result;   	
      }
      //判断是否有答案
      public static String isHasanswer(List<Map<String, Object>> result,String question){
    	  int size = result.size();
    	  if (size == 0) {
    		  return "0";
		  }
    	  else if(size>=5){
    		  double[] similarty = new double[5];
        	  for(int i=0;i<5;i++){
        		  Map<String, Object> map = result.get(i);
        		  String q_toMatch = (String) map.get("question");
        		  double score1 = new MySimHash(question).getSemblance(new MySimHash(q_toMatch));
        		  double score2 = SimilarityUtil.getSimilarity(q_toMatch, question);
        		  similarty[i] = score1*0.4+score2*0.6;
        		  
        	  }
        	  double resultScore = 0;
        	  int num = 0;
        	  for(int j=0;j<5;j++){  
        		  if (similarty[j]>resultScore) {
        			  resultScore = similarty[j];
        			  num = j;
    			  }
        	  }
        	//  System.out.println(resultScore);
        	  Map<String, Object> map1 = result.get(num);
        	  String q = (String) map1.get("question");
        	//  System.out.println(q);
        	  if (resultScore>0.6) {
        		  Map<String, Object> map = result.get(num);
        		  String answer = (String) map.get("answer");
        		  return answer;
    		  }
        	  
        	  return "0";
		  }
    	  else{
    		  double[] similarty = new double[size];
        	  for(int i=0;i<size;i++){
        		  Map<String, Object> map = result.get(i);
        		  String q_toMatch = (String) map.get("question");
        		  double score1 = new MySimHash(question).getSemblance(new MySimHash(q_toMatch));
        		  double score2 = SimilarityUtil.getSimilarity(q_toMatch, question);
        		  similarty[i] = score1*0.4+score2*0.6;
        		  
        	  }
        	  double resultScore = 0;
        	  int num = 0;
        	  for(int j=0;j<size;j++){  
        		  if (similarty[j]>resultScore) {
        			  resultScore = similarty[j];
        			  num = j;
    			  }
        	  }
        	//  System.out.println(resultScore);
        	  Map<String, Object> map1 = result.get(num);
        	  String q = (String) map1.get("question");
        	//  System.out.println(q);
        	  if (resultScore>0.6) {
        		  Map<String, Object> map = result.get(num);
        		  String answer = (String) map.get("answer");
        		  return answer;
    		  }
        	  
        	  return "0";
    	  }
    	  
      }
      //判断是否有答案
      public static String isHasanswer1(List<Map<String, Object>> result,String question){
    	  int size = result.size();
    	  if (size == 0) {
    		  return "0";
		  }
    	  else if(size>=5){
    		  double[] similarty = new double[5];
        	  for(int i=0;i<5;i++){
        		  Map<String, Object> map = result.get(i);
        		  String q_toMatch = (String) map.get("question");
        		  double score1 = new MySimHash(question).getSemblance(new MySimHash(q_toMatch));
        		  double score2 = SimilarityUtil.getSimilarity(q_toMatch, question);
        		  similarty[i] = score1*0.4+score2*0.6;
        		  
        	  }
        	  double resultScore = 0;
        	  int num = 0;
        	  for(int j=0;j<5;j++){  
        		  if (similarty[j]>resultScore) {
        			  resultScore = similarty[j];
        			  num = j;
    			  }
        	  }
        	//  System.out.println(resultScore);
        	  Map<String, Object> map1 = result.get(num);
        	  String q = (String) map1.get("question");
        	//  System.out.println(q);
        	  if (resultScore>0.75) {
        		  Map<String, Object> map = result.get(num);
        		  String answer = (String) map.get("answer");
        		  return answer;
    		  }
        	  
        	  return "0";
		  }
    	  else{
    		  double[] similarty = new double[size];
        	  for(int i=0;i<size;i++){
        		  Map<String, Object> map = result.get(i);
        		  String q_toMatch = (String) map.get("question");
        		  double score1 = new MySimHash(question).getSemblance(new MySimHash(q_toMatch));
        		  double score2 = SimilarityUtil.getSimilarity(q_toMatch, question);
        		  similarty[i] = score1*0.4+score2*0.6;
        		  
        	  }
        	  double resultScore = 0;
        	  int num = 0;
        	  for(int j=0;j<size;j++){  
        		  if (similarty[j]>resultScore) {
        			  resultScore = similarty[j];
        			  num = j;
    			  }
        	  }
        	//  System.out.println(resultScore);
        	  Map<String, Object> map1 = result.get(num);
        	  String q = (String) map1.get("question");
        	 // System.out.println(q);
        	  if (resultScore>0.75) {
        		  Map<String, Object> map = result.get(num);
        		  String answer = (String) map.get("answer");
        		  return answer;
    		  }
        	  
        	  return "0";
    	  }
    	  
      }
      public static String yin(String sentence){
    	  int senLen = sentence.length();
    	  int i=0;
    	  StringBuilder result = new StringBuilder(senLen);
    	  //TernarySearchTree
    	  
    	  
		  return null;
      }
     /**
      * 带有搜索条件的聚合查询（聚合相当于关系型数据库里面的group by）
      * @param index
      * @param type
      * @return
      */
     public static Map<String, Long> searchBucketsAggregation(String index, String type) {
     	long total = 0;
     	Map<String, Long> rtnMap = new HashMap<>();
     	SearchRequestBuilder searchRequestBuilder = client.prepareSearch(index).setTypes(type);
     	//搜索条件  
     	String dateStr = DateUtil.getDays();
        BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
        /*queryBuilder.must(QueryBuilders.matchQuery("source", "resource"))精确匹配*/
        queryBuilder.filter(QueryBuilders.boolQuery()
         					.must(QueryBuilders.rangeQuery("logTime")
         							.gte(dateStr + "000000")
         							.lte(dateStr + "235959") //时间为当天
         							.format("yyyyMMddHHmmss")));//时间匹配格式
        // 获取当日告警总数
        //long total = searchRequestBuilder.setQuery(queryBuilder).get().getHits().getTotalHits();
     	// 聚合分类（以告警类型分类）
     	TermsAggregationBuilder teamAggBuilder = AggregationBuilders.terms("source_count").field("source.keyword");
     	searchRequestBuilder.addAggregation(teamAggBuilder);
     	// 不指定 "size":0 ，则搜索结果和聚合结果都将被返回,指定size：0则只返回聚合结果
     	searchRequestBuilder.setSize(0);
     	searchRequestBuilder.setQuery(queryBuilder);
     	SearchResponse response = searchRequestBuilder.execute().actionGet();
     	
//     	System.out.println("++++++聚合分类："+response.toString());
     	
     	// 聚合结果处理
     	Terms genders = response.getAggregations().get("source_count");
         for (Terms.Bucket entry : genders.getBuckets()) {
             Object key = entry.getKey();      // Term  
             Long count = entry.getDocCount(); // Doc count
             
             rtnMap.put(key.toString(), count);
             
//           System.out.println("Term: "+key);  
//           System.out.println("Doc count: "+count);  
         }
         if(!rtnMap.isEmpty()) {
         	if(!rtnMap.containsKey("system")) {
         		rtnMap.put("system", 0L);
         	}
         	if(!rtnMap.containsKey("resource")) {
         		rtnMap.put("resource", 0L);
         	}
         	if(!rtnMap.containsKey("scheduler")) {
         		rtnMap.put("scheduler", 0L);
         	}
         	total = rtnMap.get("system") + rtnMap.get("resource") + rtnMap.get("scheduler");
         }
         if(total != 0) {
         	rtnMap.put("total", total);
         }
         return rtnMap;
     }
     /**
      * 当日流数据总量汇总
      * @param index
      * @param type
      * @param dataworkerType
      * @return
      */
     public static Map<String, Long> searchBucketsAggregation(String index, String type, String dataworkerType) {
     	Map<String, Long> rtnMap = new HashMap<>();
     	long count = 0;
     	SearchRequestBuilder searchRequestBuilder = client.prepareSearch(index).setTypes(type);
     	
//     	SumAggregationBuilder sAggBuilder = AggregationBuilders.sum("agg").field("count.keyword");
     	
     	//搜索条件  
     	String dateStr = DateUtil.getDays();
         BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
//         queryBuilder.must(QueryBuilders.matchQuery("dataworkerType", dataworkerType))
         queryBuilder.must(QueryBuilders.matchQuery("dataworkerType", dataworkerType))
         			.filter(QueryBuilders.boolQuery()
         					.must(QueryBuilders.rangeQuery("logTime")
         							.gte(dateStr + "000000")
         							.lte(dateStr + "235959")
         							.format("yyyyMMddHHmmss")));
     	searchRequestBuilder.setQuery(queryBuilder);
//     	searchRequestBuilder.addAggregation(sAggBuilder);
     	SearchResponse response = searchRequestBuilder.execute().actionGet();
     	
     //	System.out.println("++++++条件查询结果："+response.toString());
     	
     	SearchHit[] hits = response.getHits().getHits();
     	for (SearchHit searchHit : hits) {
 			Object object = searchHit.getSourceAsMap().get("count");
 			if(object != null && !"".equals(object)) {
 			//	System.out.println("=============Count:"+object.toString());
 				count += Long.parseLong(object.toString());
 			}
 		}
     //	System.out.println("======流数据量：" + count);
     	rtnMap.put(dataworkerType + "Total", count);
     //	System.out.println("======rtnMap:"+rtnMap.toString());
        return rtnMap;
     }
     /**
 	 * 读取索引类型表指定列名的总和
 	 * @param index
 	 * @param type
 	 * @param sumField
 	 * @return
 	 */
 	public static Map<String, Long> readIndexTypeFieldValueWithSum(String index, String type, String dataworkerType, String sumField) {
 		Map<String, Long> rtnMap = new HashMap<>();
 		long count = 0;
 		// 聚合结果
 		String sumName = sumField + "Sum";
 		// 搜索条件  
     	String dateStr = DateUtil.getDays();
         BoolQueryBuilder queryBuilder = QueryBuilders.boolQuery();
         queryBuilder.must(QueryBuilders.matchQuery("dataworkerType", dataworkerType))
         			.filter(QueryBuilders.boolQuery()
         					.must(QueryBuilders.rangeQuery("logTime")
         							.gte(dateStr + "000000")
         							.lte(dateStr + "235959")
         							.format("yyyyMMddHHmmss")));
 	    // 时间前缀匹配（如：20180112）
        //        PrefixQueryBuilder preQueryBuild = QueryBuilders.prefixQuery(dataworkerType, dateStr);
        //模糊匹配
        //        FuzzyQueryBuilder fuzzyQueryBuild = QueryBuilders.fuzzyQuery(name, value);
        // 范围匹配
        //        RangeQueryBuilder rangeQueryBuild = QueryBuilders.rangeQuery(name);
        // 查询字段不存在及字段值为空 filterBuilder = QueryBuilders.boolQuery().should(new BoolQueryBuilder().mustNot(existsQueryBuilder)) .should(QueryBuilders.termsQuery(field, ""));
        //    	ExistsQueryBuilder existsQueryBuilder = QueryBuilders.existsQuery(field);
        // 对某字段求和聚合（sumField字段）
 		SumAggregationBuilder aggregation = AggregationBuilders.sum(sumName).field(sumField);
 		SearchResponse response = client.prepareSearch(index).setTypes(type)
 				.setQuery(QueryBuilders.matchAllQuery())
 				.setQuery(queryBuilder)
 					.addAggregation(aggregation).execute().actionGet();
 		Sum sum = response.getAggregations().get(sumName);
 		count = new Double(sum.getValue()).longValue();
 		rtnMap.put(dataworkerType + "Total", count);
     //	System.out.println("======rtnMap:"+rtnMap.toString());
 		return rtnMap;
 	}
     
     /**
      * 按时间统计聚合
      * @param index
      * @param type
      */
     public static void dataHistogramAggregation(String index, String type) {  
         try {  
             SearchRequestBuilder searchRequestBuilder = client.prepareSearch(index).setTypes(type);  
               
             DateHistogramAggregationBuilder field = AggregationBuilders.dateHistogram("sales").field("value");  
             field.dateHistogramInterval(DateHistogramInterval.MONTH);  
//           field.dateHistogramInterval(DateHistogramInterval.days(10))  
             field.format("yyyy-MM");
             
             //强制返回空 buckets,既空的月份也返回
             field.minDocCount(0);
             
             // Elasticsearch 默认只返回你的数据中最小值和最大值之间的 buckets
             field.extendedBounds(new ExtendedBounds("2018-01", "2018-12"));
               
             searchRequestBuilder.addAggregation(field);  
             searchRequestBuilder.setSize(0);  
             SearchResponse searchResponse = searchRequestBuilder.execute().actionGet();  
               
         //    System.out.println(searchResponse.toString());
               
             Histogram histogram = searchResponse.getAggregations().get("sales");  
             for (Histogram.Bucket entry : histogram.getBuckets()) {  
//               DateTime key = (DateTime) entry.getKey();   
                 String keyAsString = entry.getKeyAsString();   
                 Long count = entry.getDocCount(); // Doc count  
                   
             //    System.out.println("======="+keyAsString + "，销售" + count + "辆");
             }  
         } catch (Exception e) {  
              e.printStackTrace();  
         }  
    }
     /**
      * 范围查询
      * @throws Exception
      */
     public static void rangeQuery() {
     	
     	//查询字段不存在及字段值为空 filterBuilder = QueryBuilders.boolQuery().should(new BoolQueryBuilder().mustNot(existsQueryBuilder)) .should(QueryBuilders.termsQuery(field, ""));
//     	ExistsQueryBuilder existsQueryBuilder = QueryBuilders.existsQuery(field);
     	
         //term精确查询
//         QueryBuilder queryBuilder = QueryBuilders.termQuery("age", 50) ;  //年龄等于50
         //range查询
         QueryBuilder rangeQueryBuilder = QueryBuilders.rangeQuery("age").gt(20); //年龄大于20
         SearchResponse searchResponse = client.prepareSearch("index_test")
               .setTypes("type_test")
               .setQuery(rangeQueryBuilder)     //query
               .setPostFilter(QueryBuilders.rangeQuery("age").from(40).to(50)) // Filter
//               .addSort("age", SortOrder.DESC)
               .setSize(120)   // 不设置的话，默认取10条数据
               .execute().actionGet();
         SearchHits hits = searchResponse.getHits();
     //    System.out.println("查到记录数："+hits.getTotalHits());
         SearchHit[] searchHists = hits.getHits();
         if(searchHists.length>0){
            for(SearchHit hit:searchHists){
               String name =  (String) hit.getSourceAsMap().get("username");
               Integer age = Integer.parseInt(hit.getSourceAsMap().get("age").toString());
         //      System.out.println("姓名：" + name + " 年龄：" + age);
            }
         }
      }
     
     /**
      * 时间范围查询
      * @param index
      * @param type
      * @param startDate
      * @param endDate
      */
     public static void rangeQuery(String index, String type, String startDate, String endDate) {
     	BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();      
//         boolQueryBuilder.must(queryBuilders);      
         boolQueryBuilder.filter(QueryBuilders.boolQuery().must(      
                 QueryBuilders.rangeQuery("time").gte(startDate).lte(endDate).format("yyyyMMddHHmmss")));      
       
         SearchResponse searchResponse = client.prepareSearch(index).setTypes(type)      
                 .setSearchType(SearchType.DFS_QUERY_THEN_FETCH)      
                 .setQuery(boolQueryBuilder)  
                 .addAggregation(AggregationBuilders.terms("value_count").field("value.keyword")).get();   
                 //Terms Aggregation  名称为terms1_count 字段为field1   下面的也类似  
//                 .addAggregation(AggregationBuilders.terms("terms2_count").field("field2"));
         
      //   System.out.println("时间范围查询结果： "+searchResponse.toString());
         
         SearchHit[] hits = searchResponse.getHits().getHits();
     	List<Map<String, Object>> mapList = new ArrayList<>();
     	for (SearchHit searchHit : hits) {
 			Map<String, Object> map = searchHit.getSourceAsMap();
 			mapList.add(map);
 		}
     //    System.out.println(mapList.toString());
     }
     
     /**
      * 功能描述：关闭链接
      */
     public static void close() {
         client.close();
     }
     
     /**
      * 在Elasticsearch老版本中做数据遍历一般使用Scroll-Scan。Scroll是先做一次初始化搜索把所有符合搜索条件的结果缓存起来生成一个快照，
      * 然后持续地、批量地从快照里拉取数据直到没有数据剩下。而这时对索引数据的插入、删除、更新都不会影响遍历结果，因此scroll 并不适合用来做实时搜索。
      * Scan是搜索类型，告诉Elasticsearch不用对结果集进行排序，只要分片里还有结果可以返回，就返回一批结果。
      * 在5.X版本中SearchType.SCAN已经被去掉了。根据官方文档说明，使用“_doc”做排序可以达到更高性能的Scroll查询效果，
      * 这样可以遍历所有文档而不需要进行排序。
      * @param index
      * @param type
      */
 	public static void scroll(String index, String type) {
    // 	System.out.println("scroll()方法开始.....");
     	List<JSONObject> lst = new ArrayList<JSONObject>();
        SearchResponse searchResponse = client.prepareSearch(index)  
                 .setTypes(type)  
                 .setQuery(QueryBuilders.matchAllQuery())  
                 .addSort(SortBuilders.fieldSort("_doc"))
                 .setSize(30)  
                 // 这个游标维持多长时间  
                 .setScroll(TimeValue.timeValueMinutes(8)).execute().actionGet();  
           
     //    System.out.println("getScrollId: "+searchResponse.getScrollId());
     //    System.out.println("匹配记录数："+searchResponse.getHits().getTotalHits());
     //    System.out.println("hits长度："+searchResponse.getHits().getHits().length);
         for (SearchHit hit : searchResponse.getHits()) {
             String json = hit.getSourceAsString();
             try {
             	JSONObject jsonObject = new JSONObject(json);
             	lst.add(jsonObject);
             } catch (JSONException e) {
                 e.printStackTrace();
             }
         }
      //   System.out.println("======" + lst.toString());
      //   System.out.println("======" + lst.get(0).get("username"));
         // 使用上次的scrollId继续访问  
//         croll scroll = new ScrollTest2();
//         do{  
//             int num = scroll.scanData(esClient,searchResponse.getScrollId())
//             if(num ==0) break;  
//         }while(true);  
      //   System.out.println("------------------------------END");
     }
     
     /**
 	 * 分词
 	 * @param index
 	 * @param text
 	 */
 	public static void analyze(String index, String text) {
 		TransportClient client = StaticContant.ESCLIENT;
 		AnalyzeRequestBuilder request = new AnalyzeRequestBuilder(client, AnalyzeAction.INSTANCE,index).setText(text);
 		request.setAnalyzer("ik-index");
 		List<AnalyzeToken> analyzeTokens = request.execute().actionGet().getTokens();
 		for (int i = 0, len = analyzeTokens.size(); i < len; i++) {
 			AnalyzeToken analyzeToken = analyzeTokens.get(i);
 		//	System.out.println(analyzeToken.getTerm());
 		}
 	}
 	/**
 	 * 默认的单字分词
 	 * @param text
 	 */
 	public static void analyze(String text) {
 		AnalyzeRequest analyzeRequest = new AnalyzeRequest();
 		analyzeRequest.text(text);
 		ActionFuture<AnalyzeResponse> analyzeResponseActionFuture = StaticContant.ESCLIENT.admin()
 				.indices().analyze(analyzeRequest);
 		List<AnalyzeResponse.AnalyzeToken> analyzeTokens = analyzeResponseActionFuture.actionGet().getTokens();
 		for(AnalyzeResponse.AnalyzeToken analyzeToken:analyzeTokens){
 		//	System.out.println(analyzeToken.getTerm());
 		}
 	}

}
