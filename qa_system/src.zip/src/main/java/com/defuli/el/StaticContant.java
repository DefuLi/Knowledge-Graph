package com.defuli.el;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.TransportAddress;
import org.elasticsearch.transport.client.PreBuiltTransportClient;

public class StaticContant {
	static TransportClient ESCLIENT; 
	static{
		try {
			Settings settings = Settings.builder()
					.put("cluster.name", "elasticsearch") 	//设置集群名
	                .put("client.transport.sniff", true) 		//启动嗅探功能,自动嗅探整个集群的状态，把集群中其他ES节点的ip添加到本地的客户端列表中
	                .put("client.transport.ignore_cluster_name", true)//忽略集群名字验证, 打开后集群名字不对也能连接上
	                //.put("client.transport.nodes_sampler_interval", 5)//报错
	                //.put("client.transport.ping_timeout", 5) 		//报错, ping等待时间
	                .build();
	        // 创建client,通过setting来创建，若不指定则默认链接的集群名为elasticsearch,链接使用tcp协议即9300
	        // addTransportAddress此步骤添加IP，至少一个，其实一个就够了，因为添加了自动嗅探配置
			ESCLIENT = new PreBuiltTransportClient(settings)
			        .addTransportAddress(new TransportAddress(InetAddress.getByName("localhost"), 9300));
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
