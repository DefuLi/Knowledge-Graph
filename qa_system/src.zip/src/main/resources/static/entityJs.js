//——————————————————————————————————————
//                             entity界面类函数
//——————————————————————————————————————

//初始化entity界面的函数
function iniEntityHtml() {
    
}

//查询实体的函数
function queryText() {
    typeA=$("#aText").text();
    queryContent=$("#inputEntity").val(); //获取input输入框内容

    if (typeA=='实体查询'){
        jQuery.ajax({
            url:"entity/queryEntity",
            type:"post",
            dataType:"text",
            async:false,
            data:{queryContent:queryContent},
            success:function (data) {
                processJsonFromQueryEntity(data);
            }
        })
    }
    else if(typeA=='属性查询'){
        jQuery.ajax({
            url:"property/queryProperty",
            type:"post",
            dataType:"text",
            async:false,
            data:{queryContent:queryContent},
            success:function (data) {
                processJsonFromQueryProperty(data);
            }
        })
    }
    else if(typeA=='关系查询'){
        jQuery.ajax({
            url:"relationship/queryRelationship",
            type:"post",
            dataType:"text",
            async:false,
            data:{queryContent:queryContent},
            success:function (data) {
                processJsonFromQueryRelationship(data);
            }
        })
    }

}

//——————————————————————————————————————
//                             工具类函数
//——————————————————————————————————————

//处理服务器queryEntity函数返回的Json数据
function processJsonFromQueryEntity(jsonData) {
    var jsonObj=JSON.parse(jsonData);
    $('tr').remove();
    $.each(jsonObj,function (i) {
        var entityName=jsonObj[i]["实体型号"];
        var entityContent=jsonObj[i]["实体内容"];
        console.log(entityName+"\n"+entityContent);
        console.log("\n");

        $('table').append('<tr><td><b>实体型号：</b>'+entityName+'<br><b>实体内容：</b>'+entityContent+'<br><br></td></tr>');
    })
}

function processJsonFromQueryProperty(jsonData) {
    var jsonObj=JSON.parse(jsonData);
    $('tr').remove();
    $.each(jsonObj,function (i) {
        var entityTypeName=jsonObj[i]["entityTypeName"];
        var propertyName=jsonObj[i]["propertyName"];
        var answer=jsonObj[i]["answer"];
        console.log(entityTypeName)
        console.log(propertyName)
        console.log(answer)
        $('table').append('<tr><td><b>实体型号：</b>'+entityTypeName+'<br><b>实体属性：</b>'+propertyName+'<br><b>答案：</b>'+answer+'<br><br></td></tr>');
    })
}

//处理服务器queryRelationship函数返回的Json数据
function processJsonFromQueryRelationship(jsonData) {
    var jsonObj=JSON.parse(jsonData);
    removeDuplicatEntityName=removeDuplicat(jsonObj);
    $('tr').remove();
    for (var j = 0; j < removeDuplicatEntityName.length; j++) {
        var relationEnd="";
        var entityName="";
        var entityRelation="";
        var answer="";

        $.each(jsonObj, function (i) {
            var relationStar=jsonObj[i]["relationStar"];
            var relationship=jsonObj[i]["relationship"];
            var relationEndTemp=jsonObj[i]["relationEnd"];
            if (relationStar==removeDuplicatEntityName[j]){
                if(relationship=="取证"){
                    relationEnd=relationEnd+relationEndTemp+"  ";
                    answer=relationEnd;
                }
                else if(relationStar=="硬件类型"&&relationship=="拥有"){
                    relationEnd=relationEnd+relationEndTemp+"  ";
                }
                else if(relationStar=="软件类型"&&relationship=="拥有"){
                    relationEnd=relationEnd+relationEndTemp+"  ";
                }
                else {
                    relationEnd=relationEnd+"<a onclick='toAnswerDetail(this)'>"+relationEndTemp+"</a>"+"&nbsp;&nbsp;&nbsp;";
                }

                answer=relationEnd;
            }
            entityName=removeDuplicatEntityName[j];
            entityRelation=relationship;
        })
        $('table').append('<tr><td><b>实体：</b>'+entityName+'<br><b>关系：</b>'+entityRelation+'<br><b>答案：</b>'+answer+'<br><br></td></tr>');
    }


}

//去重
function removeDuplicat(jsonObj) {
    var setArray=[];
    var returnArray=[];
    $.each(jsonObj,function (i) {
        var entityName=jsonObj[i]["relationStar"];
        setArray.push(entityName);
    })
    for (var i = 0; i <setArray.length ; i++) {
        var current=setArray[i];
        if (returnArray.indexOf(current)==-1){
            returnArray.push(current);
        }
    }
    return returnArray;
}

//跳转到answerDetail.html 传递点击中的参数
function toAnswerDetail(e) {
    var clickData=$(e).text();
    var url=encodeURI("answerDetail?clickData="+clickData);
    window.open(url);

}