//——————————————————————————————————————
//                             communication界面类函数
//——————————————————————————————————————



function temp(){

}

//查询实体的函数
function commu() {
    //禁用文本框和按钮  打开加载动画
    $('#loader').show();
    $('#commText').attr('disabled',true);
    $('#btnComm').attr('disabled',true);

    queryContent=$("#commText").val(); //获取input输入框内容
    jQuery.ajax({
        url:"communication/comm",
        type:"post",
        dataType:"text",
        async:true,
        data:{queryContent:queryContent},
        success:function (data) {
            processFromComm(data);
        }
    })

}

//——————————————————————————————————————
//                             工具类函数
//——————————————————————————————————————

//处理服务器queryEntity函数返回的Json数据
function processFromComm(jsonData) {
    $('tr').remove();
    queryContent=$("#commText").val(); //获取input输入框内容
    $('table').append('<tr><td><b>闲聊问题：</b>'+queryContent+'<br><b>闲聊答案：</b>'+jsonData+'<br><br></td></tr>');
    $('#loader').hide();
    $('#commText').attr('disabled',false);
    $('#btnComm').attr('disabled',false);




}