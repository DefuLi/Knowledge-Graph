//——————————————————————————————————————
//                             neo4jDataStructure界面类函数
//——————————————————————————————————————

//echarts绘制tree图
function treeFig() {
    var myChart = echarts.init(document.getElementById('treeFig'));
    myChart.setOption(option = {
        tooltip: {
            trigger: 'item',
            triggerOn: 'mousemove'
        },
        series: [
            {
                type: 'tree',
                data: [
                    {name:"取证产品（取证）",
                        children:[
                            {
                                name:"硬件类型（拥有）",
                                children:[
                                    {
                                        name:"智能机"
                                    },
                                    {
                                        name:"笔记本电脑"
                                    },
                                    {
                                        name:"U盘"
                                    },
                                    {
                                        name:"SD卡闪存卡"
                                    },
                                    {
                                        name:"银行卡"
                                    },
                                    {
                                        name:"汽车"
                                    },
                                    {
                                        name:"功能机"
                                    },
                                    {
                                        name:"山寨机"
                                    },
                                    {
                                        name:"安卓手机"
                                    },
                                    {
                                        name:"苹果手机"
                                    },
                                    {
                                        name:"手机芯片"
                                    },
                                    {
                                        name:"硬盘"
                                    },
                                    {
                                        name:"服务器"
                                    },
                                    {
                                        name:"sim卡"
                                    }
                                ]
                            },
                            {
                                name:"软件类型（拥有）",
                                children:[
                                    {
                                        name:"云存储"
                                    },
                                    {
                                        name:"即时通讯"
                                    },
                                    {
                                        name:"地图导航"
                                    },
                                    {
                                        name:"安全管家"
                                    },
                                    {
                                        name:"微博"
                                    },
                                    {
                                        name:"打车软件"
                                    },
                                    {
                                        name:"浏览器"
                                    },
                                    {
                                        name:"电子商务"
                                    },
                                    {
                                        name:"输入法"
                                    },
                                    {
                                        name:"邮箱"
                                    }
                                ]
                            }
                        ],

                    },
                ],
                top: '0%',
                left: '20%',
                bottom: '10%',
                right:'20%',

                symbolSize: 10,
                label: {
                    normal: {
                        position: 'left',
                        verticalAlign: 'middle',
                        align: 'right',
                        fontSize: 15
                    }
                },

                leaves: {
                    label: {
                        normal: {
                            position: 'right',
                            verticalAlign: 'middle',
                            align: 'left'
                        }
                    }
                },

                expandAndCollapse: true,
                animationDuration: 550,
                animationDurationUpdate: 750
            }
        ]
    });
}
