//——————————————————————————————————————
//                             realtionship界面类函数
//——————————————————————————————————————

//初始化relationship界面的函数
function iniRelationshipHtml() {

}

//查询关系的函数
function queryRelationship() {
    queryContent=$("#inputRelationship").val(); //获取input输入框内容
    jQuery.ajax({
        url:"relationship/queryRelationship",
        type:"post",
        dataType:"text",
        async:false,
        data:{queryContent:queryContent},
        success:function (data) {
            processJsonFromQueryRelationship(data);
        }
    })
}

//——————————————————————————————————————
//                             工具类函数
//——————————————————————————————————————

// //处理服务器queryRelationship函数返回的Json数据
// function processJsonFromQueryRelationship(jsonData) {
//     var jsonObj=JSON.parse(jsonData);
//     removeDuplicatEntityName=removeDuplicat(jsonObj);
//     $('tr').remove();
//     for (var j = 0; j < removeDuplicatEntityName.length; j++) {
//         var relationEnd="";
//         var entityName="";
//         var entityRelation="";
//         var answer="";
//
//         $.each(jsonObj, function (i) {
//             var relationStar=jsonObj[i]["relationStar"];
//             var relationship=jsonObj[i]["relationship"];
//             var relationEndTemp=jsonObj[i]["relationEnd"];
//             if (relationStar==removeDuplicatEntityName[j]){
//                 if(relationship=="取证"){
//                     relationEnd=relationEnd+relationEndTemp+"  ";
//                     answer=relationEnd;
//                 }
//                 else if(relationStar=="硬件类型"&&relationship=="拥有"){
//                     relationEnd=relationEnd+relationEndTemp+"  ";
//                 }
//                 else if(relationStar=="软件类型"&&relationship=="拥有"){
//                     relationEnd=relationEnd+relationEndTemp+"  ";
//                 }
//                 else {
//                 relationEnd=relationEnd+"<a onclick='toAnswerDetail(this)'>"+relationEndTemp+"</a>"+"&nbsp;&nbsp;&nbsp;";
//                 }
//
//                 answer=relationEnd;
//             }
//             entityName=removeDuplicatEntityName[j];
//             entityRelation=relationship;
//         })
//         $('table').append('<tr><td><b>实体：</b>'+entityName+'<br><b>关系：</b>'+entityRelation+'<br><b>答案：</b>'+answer+'<br><br></td></tr>');
//     }
//
//
// }
//
// //去重
// function removeDuplicat(jsonObj) {
//     var setArray=[];
//     var returnArray=[];
//     $.each(jsonObj,function (i) {
//         var entityName=jsonObj[i]["relationStar"];
//         setArray.push(entityName);
//     })
//     for (var i = 0; i <setArray.length ; i++) {
//         var current=setArray[i];
//         if (returnArray.indexOf(current)==-1){
//             returnArray.push(current);
//         }
//     }
//     return returnArray;
// }
//
// //跳转到answerDetail.html 传递点击中的参数
// function toAnswerDetail(e) {
//     var clickData=$(e).text();
//     var url=encodeURI("answerDetail?clickData="+clickData);
//     window.open(url);
//
// }