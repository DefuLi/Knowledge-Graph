//——————————————————————————————————————
//                             product界面类函数
//——————————————————————————————————————

var finalVar="";

//查询实体的函数
function productQA() {
    //禁用文本框和按钮  打开加载动画
    $('#loader').show();
    $('#btnQA').attr('disabled',true);
    $('#productText').attr('disabled',true);

    queryContent=$("#productText").val(); //获取input输入框内容
    jQuery.ajax({
        url:"product/productQA",
        type:"post",
        dataType:"text",
        async:true,
        data:{queryContent:queryContent},
        success:function (data) {
           processJsonFromProductQA(data);
        }
    })

}

//——————————————————————————————————————
//                             工具类函数
//——————————————————————————————————————

function isJsonString(str) {
    try {
        if (typeof JSON.parse(str) == "object") {
            return true;
        }
    } catch(e) {
    }
    return false;
}

//处理服务器queryEntity函数返回的Json数据
function processJsonFromProductQA(jsonData) {
    $('tr').remove();
    if (isJsonString(jsonData)){
        //是json对象  专业问题
        var jsonObj=JSON.parse(jsonData);
        $.each(jsonObj,function (i) {
            var questionVal=jsonObj[i]["question"];
            var answerVal=jsonObj[i]["answer"];
            if (i==0){
                if (answerVal.indexOf("mht")!=-1){
                    $('table').append('<tr><td><b>问题：</b>'+questionVal+'<br><b>推荐答案：</b><a href="#">'+answerVal+'</a><br><br></td></tr>');
                    $('table').append('<tr><td>===================================================以下为相似问题推荐=================================================</td></tr>');
                } else {
                    $('table').append('<tr><td><b>问题：</b>'+questionVal+'<br><b>推荐答案：</b>'+answerVal+'<br><br></td></tr>');
                    $('table').append('<tr><td>===================================================以下为相似问题推荐=================================================</td></tr>');

                }
            }else {
                if (answerVal.indexOf("mht")!=-1) {
                    $('table').append('<tr><td><b>可能想问该问题：</b>'+questionVal+'<br><b>推荐答案：</b><a href="#">'+answerVal+'</a><br><br></td></tr>');
                }else{
                    $('table').append('<tr><td><b>可能想问该问题：</b>'+questionVal+'<br><b>推荐答案：</b>'+answerVal+'<br><br></td></tr>');

                }

            }
        })
    } else {
        queryContent=$("#productText").val(); //获取input输入框内容
        $('table').append('<tr><td><b>闲聊问题：</b>'+queryContent+'<br><b>闲聊答案：</b>'+jsonData+'<br><br></td></tr>');
    }
    $('#loader').hide();
    $('#btnQA').attr('disabled',false);
    $('#productText').attr('disabled',false);

}

//监听输入框的输入
function keyUp() {
    $('a').remove();
    $('br').remove();
    queryContent=$('#productText').val();
    console.log(queryContent)
    jQuery.ajax({
        url:"product/recommendQuestion",
        type:"post",
        dataType:"text",
        async:true,
        data:{queryContent:queryContent},
        success:function (data) {
           // $('#temp').remove();

            processJsonFromRecommendQuestion(data);

        }
    })
}

//处理服务器返回的json对象 推荐问题
function processJsonFromRecommendQuestion(jsonData) {
   // $('#temp').remove();
    var jsonObj=JSON.parse(jsonData);
    finalVar=jsonObj;
    $.each(jsonObj,function (i) {
        if (i<5){
            var questionVal=jsonObj[i]["question"];
            var answerVal=jsonObj[i]["answer"];
            console.log(questionVal);
            $('#recommQues').append('<br><a href="javascript:search('+i+')">'+questionVal+'</a>')
        }
    })
}

function search(data) {
    $('#loader').show();
    $('#btnQA').attr('disabled',true);
    $('#productText').attr('disabled',true);
    temp=finalVar[data]["question"];
    jQuery.ajax({
        url:"product/productQA",
        type:"post",
        dataType:"text",
        async:true,
        data:{queryContent:temp},
        success:function (data) {
            processJsonFromProductQA(data);
        }
    })
}

function hisRecord() {
    jQuery.ajax({
        url:"product/hisRecord",
        type:"post",
        dataType:"text",
        async:true,
        success:function (data) {
            var hisrecord=data.split("+")
            var result="";
            for (i=0;i<hisrecord.length;i++){
                result=result+hisrecord[i]+"\n";
            }
            alert(result)
        }
    })
}