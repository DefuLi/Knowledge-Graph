//——————————————————————————————————————
//                             property界面类函数
//——————————————————————————————————————

//初始化property界面的函数
function iniPropertyHtml() {

}

//查询实体的函数
function queryProperty() {
    queryContent=$("#inputProperty").val(); //获取input输入框内容
    jQuery.ajax({
        url:"property/queryProperty",
        type:"post",
        dataType:"text",
        async:false,
        data:{queryContent:queryContent},
        success:function (data) {
            processJsonFromQueryProperty(data);
        }
    })
}

//——————————————————————————————————————
//                             工具类函数
//——————————————————————————————————————

//处理服务器queryProperty函数返回的Json数据
// function processJsonFromQueryProperty(jsonData) {
//     var jsonObj=JSON.parse(jsonData);
//     $('tr').remove();
//     $.each(jsonObj,function (i) {
//         var entityTypeName=jsonObj[i]["entityTypeName"];
//         var propertyName=jsonObj[i]["propertyName"];
//         var answer=jsonObj[i]["answer"];
//         console.log(entityTypeName)
//         console.log(propertyName)
//         console.log(answer)
//         $('table').append('<tr><td><b>实体型号：</b>'+entityTypeName+'<br><b>实体属性：</b>'+propertyName+'<br><b>答案：</b>'+answer+'<br><br></td></tr>');
//     })
// }