function load_firstData() {
    selectRelation="取证";
    var selectNum=30;
    $.post("firstKeynote/loadData",{selectRelation:selectRelation,selectNum:selectNum}, function (data) {
        var jsonObjData=JSON.parse(data);
        var linksData=new Array();
        $.each(jsonObjData, function(i) {
            //生成links的数据
            var sourceAndTarget={"source":jsonObjData[i]["source"],"target":jsonObjData[i]["target"]};
            linksData.push(sourceAndTarget);
        });
        nodesData=convert(jsonObjData);
        //填画图代码
        var myChart = echarts.init(document.getElementById('main'));
        var option = {
            title: {
                text: '可视化图数据',
                subtext: '数据来自neo4j',
                x: 'right',
                y: 'bottom'
            },
            tooltip: {
                show:true,
                trigger: 'item',
                showContent:false,
                formatter:function(parmas,ticket,callback){
                    var fouseName=parmas.data.name;
                    var fouseIdTemp=fouseName.replace(/[^0-9]/ig,"");
                    var fouseId=fouseIdTemp.substr(fouseIdTemp.length-6);
                    //通过聚焦获取节点Id，然后post请求得到该Id的内容
                    $.post("firstKeynote/focusIdContent",{fouseId:fouseId},function (data) {
                        focusIdContent=data;
                    })

                    //鼠标双击事件
                    document.ondblclick=function () {
                        //双击事件是去刷新界面，延展该节点的其它关系
                        dbclickNode(fouseId);
                    }

                    //屏蔽系统右击选项
                    document.oncontextmenu=function (e) {
                        e.preventDefault();
                    }
                    //鼠标右击事件
                    document.onmouseup=function (e) {
                        if (e.button==2) {
                            // 先把之前的弹窗清除（如果有）
                            if ($('#dialog')) {
                                closeDialog();
                            }
                            showDialog(focusIdContent);
                        }
                    }
                    $(document).on('click', '#close', (e) => {
                        closeDialog();
                });
                }
            },
            toolbox: {
                show: true,
                x:'right',
                y:'top',
                feature: {
                    restore: {show: true,title: "还原"},
                    saveAsImage: {show: true,title:"保存图片"}
                }
            },
            series: [
                {
                    type: 'force',
                    name: "产品属性",
                    ribbonType: false,
                    linkSymbol:'arrow',
                    itemStyle: {
                        normal: {
                            label: {
                                show: true,
                                textStyle: {
                                    color: '#333'
                                }
                            },
                            nodeStyle: {
                                brushType: 'both',
                                borderColor: 'rgba(255,215,0,0.4)',
                                borderWidth: 1
                            },
                            //给连接线 加标签
                            linkStyle: {
                                type: 'curve',
                                text:selectRelation,
                                textPosition:'inside'
                            }
                        },
                        emphasis: {
                            label: {
                                show: false
                                // textStyle: null      // 默认使用全局文本样式，详见TEXTSTYLE
                            },
                            nodeStyle: {
                                //r: 30
                            },
                            linkStyle: {}
                        }
                    },
                    useWorker: false,
                    minRadius: 15,
                    maxRadius: 25,
                    gravity: 1.1,
                    scaling: 1.1,
                    roam: 'move',
                    symbolSize:30,
                    nodes: nodesData,
                    links: linksData
                }
            ]
        };
        myChart.setOption(option);
    })
}

//传进来data，去掉重复值
function convert(data) {
    // 通过字典去重
    let temp = {}
    for (let e of data) {
        const t = e['target']
        const s = e['source']
        temp[t] = true
        temp[s] = true
    }

    // 转化为list
    let res = []
    for (let name in temp) {
        res.push({'name': name})
    }
    return res
}

//弹出focusIdContent变量值，弹窗
function showDialog(data) {
    let domStr =
        `<div class="dialog" id="dialog">
                    <div class="header">
                        <div class="titleContent">设备简介</div>
                        <div class="close" id="close">×</div>
                    </div>
                    <div class="content">
                        <p class="font" id="font">${data}</p>
                    </div>
                 </div>`
    let domDiv = document.createElement('div');
    domDiv.innerHTML = domStr;
    $('body').append(domDiv);
}

// 关闭弹窗函数
function closeDialog() {
    $('#dialog').parent().remove();
}

//双击节点，传入节点Id，返回得到与该节点所有有关的图
function dbclickNode(fouseId) {
    //先判断fouseId节点是否有属于或包括，如果有，用户自主选择
    jQuery.ajax({
        url:"firstKeynote/isBelongOrInclude",
        type:"post",
        dataType:"text",
        async:false,
        data:{fouseId:fouseId},
        success:function (data) {
            //请求成功，返回1，该节点的关系有包括和属于；返回2，该节点关系只有属于；返回3，其他所有情况
            if(data=="1"){
                //   alert("这是返回的data=1")
                //弹出选择框
                $('#myModalLabel').text("当前选择节点ID："+fouseId);
                $('#myModal').modal('show');

            }
            if(data=="2"){
                //    alert("这是返回的data=2");
                onlyBelong(fouseId);
            }
            if(data=="3"){
                //   alert("这是返回的data=3")
                jQuery.ajax({
                    url:"firstKeynote/dbclickNode",
                    type:"post",
                    dataType:"text",
                    async:false,
                    data:{fouseId:fouseId},
                    success:function (data) {
                        console.log("ajax成功");
                        console.log(data);
                        daclickOption(data);
                    }
                })
            }
        }
    })

    return selectRelation;
}

//双击节点，需要画图函数
function daclickOption(data){
    var jsonObjData=JSON.parse(data);
    var linksData=new Array();
    selectRelation="";
    $.each(jsonObjData, function(i) {
        //生成links的数据
        var sourceAndTarget={"source":jsonObjData[i]["source"],"target":jsonObjData[i]["target"]};
        linksData.push(sourceAndTarget);
        selectRelation=jsonObjData[i]["selectRelation"];
    });
    nodesData=convert(jsonObjData);
    console.log(nodesData);
    console.log(linksData);
    //填画图代码
    var myChart = echarts.init(document.getElementById('main'));
    var option = {
        title: {
            text: '可视化图数据',
            subtext: '数据来自neo4j',
            x: 'right',
            y: 'bottom'
        },
        tooltip: {
            show:true,
            trigger: 'item',
            showContent:false,
            formatter:function(parmas,ticket,callback){
                var fouseName=parmas.data.name;
                var fouseIdTemp=fouseName.replace(/[^0-9]/ig,"");
                var fouseId=fouseIdTemp.substr(fouseIdTemp.length-6);
                //通过聚焦获取节点Id，然后post请求得到该Id的内容
                $.post("firstKeynote/focusIdContent",{fouseId:fouseId},function (data) {
                    focusIdContent=data;
                })

                //鼠标双击事件
                document.ondblclick=function () {
                    //双击事件是去刷新界面，延展该节点的其它关系
                    dbclickNode(fouseId);
                }

                //屏蔽系统右击选项
                document.oncontextmenu=function (e) {
                    e.preventDefault();
                }
                //鼠标右击事件
                document.onmouseup=function (e) {
                    if (e.button==2) {
                        // 先把之前的弹窗清除（如果有）
                        if ($('#dialog')) {
                            closeDialog();
                        }
                        showDialog(focusIdContent);
                    }
                }
                $(document).on('click', '#close', (e) => {
                    closeDialog();
            });
            }
        },
        toolbox: {
            show: true,
            x:'right',
            y:'top',
            feature: {
                restore: {show: true,title: "还原"},
                saveAsImage: {show: true,title:"保存图片"}
            }
        },
        series: [
            {
                type: 'force',
                name: "产品属性",
                ribbonType: false,
                linkSymbol:'arrow',
                itemStyle: {
                    normal: {
                        label: {
                            show: true,
                            textStyle: {
                                color: '#333'
                            }
                        },
                        nodeStyle: {
                            brushType: 'both',
                            borderColor: 'rgba(255,215,0,0.4)',
                            borderWidth: 1
                        },
                        //给连接线 加标签
                        linkStyle: {
                            type: 'curve',
                            text:selectRelation,
                            textPosition: 'inside'
                        }
                    },
                    emphasis: {
                        label: {
                            show: false
                            // textStyle: null      // 默认使用全局文本样式，详见TEXTSTYLE
                        },
                        nodeStyle: {
                            //r: 30
                        },
                        linkStyle: {}
                    }
                },
                useWorker: false,
                minRadius: 15,
                maxRadius: 25,
                gravity: 1.1,
                scaling: 1.1,
                roam: 'move',
                symbolSize:30,
                nodes: nodesData,
                links: linksData
            }
        ]
    };
    myChart.setOption(option);

    console.log("11")
    console.log(selectRelation);
    return selectRelation;
}

//点击模态框属于按钮
function belong(){
    //首先获取到标题Id
    var fouseId=$('#myModalLabel').text();
    fouseId=fouseId.replace(/[^0-9]/ig,"");

    jQuery.ajax({
        url:"firstKeynote/clickBelong",
        type:"post",
        dataType:"text",
        async:false,
        data:{fouseId:fouseId},
        success:function (data) {
            daclickOption(data);
        }
    })
    $('#myModal').modal('hide');
}

//点击模态框包括按钮
function include() {
    //首先获取到标题Id
    var fouseId=$('#myModalLabel').text();
    fouseId=fouseId.replace(/[^0-9]/ig,"");

    jQuery.ajax({
        url:"firstKeynote/dbclickNode",
        type:"post",
        dataType:"text",
        async:false,
        data:{fouseId:fouseId},
        success:function (data) {
            daclickOption(data);
        }
    })
    $('#myModal').modal('hide');
}

//该节点只有属于，可视化出来所有属于
function onlyBelong(fouseId) {
    jQuery.ajax({
        url:"firstKeynote/onlyBelong",
        type:"post",
        dataType:"text",
        async:false,
        data:{fouseId:fouseId},
        success:function (data) {
            console.log("这是必须输出的")
            console.log(data)
            daclickOption(data);
        }
    })
}